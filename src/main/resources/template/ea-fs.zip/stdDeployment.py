import re, sys, inspect, os

appName = 'sapws'
warPath = os.path.join(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))),'target','sapws.war')
print('full path =', warPath) # script directory

weblogicUrl = 't3://sm-sapstd-web.gksm.local:7001'
userName = 'Developer'
password = 'Welcome1'

connect(userName, password, weblogicUrl)

appList = re.findall(appName, ls('/AppDeployments'))
if len(appList) >= 1:
    print 'undeploying application'
    undeploy(appName)

deploy(appName, targets='sapstd_1', path = warPath, retireTimeout = -1, upload = 'True')
exit()
# C:\Oracle\Middleware\Oracle_Home\oracle_common\common\bin\wlst.sh testDeployment.py