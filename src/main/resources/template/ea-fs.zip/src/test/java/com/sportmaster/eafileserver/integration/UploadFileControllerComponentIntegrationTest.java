package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.request.FileAsJsonReqDto;
import com.sportmaster.eafileserver.service.JsonMapperService;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.UPLOAD;
import static java.util.Objects.requireNonNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.FORBIDDEN;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:test.properties")
public class UploadFileControllerComponentIntegrationTest extends BaseFileControllerIntegrationTest {
    @Autowired
    private PropConfig propConfig;
    @Autowired
    private JsonMapperService mapperService;
    private Token token;

    @Before
    public void init() {
        token = tokenMock.getToken(UPLOAD);
        token.setFullName(filename);
        token.setFromServer("TST1");
    }

    @Test
    public void upload_OK() {
        String param = tokenMock.getParam(token);
        ResponseEntity<String> response = uploadBody(param, null, null);
        assertEquals(CREATED, response.getStatusCode());
        assertTrue(requireNonNull(response.getBody()).length() > 0);
    }

    @Test
    public void upload_username_null_Fail() {
        token.setUsername(null);
        String param = tokenMock.getParam(token);
        ResponseEntity<String> response = uploadBody(param, null, null);
        assertEquals(FORBIDDEN, response.getStatusCode());
    }

    @Test
    public void upload_fromServer_null_Fail() {
        token.setFromServer(null);
        String param = tokenMock.getParam(token);
        ResponseEntity<String> response = uploadBody(param, null, null);
        assertEquals(FORBIDDEN, response.getStatusCode());
    }

    @Test
    public void upload_fullName_null_Fail() {
        token.setFullName(null);
        String param = tokenMock.getParam(token);
        ResponseEntity<String> response = uploadBody(param, null, null);
        assertEquals(FORBIDDEN, response.getStatusCode());
    }

    @Test
    public void upload_as_clob_Filename_length_500b_OK() throws IOException {
        filename = "1234dfsglkjhdfgkjhdfkjhgkdfkjhxkbjhxvbkcvjhbckvjbhcvkbhcvkbdfgjdlfkjglkdfjglkdfjlgkjdflgkjdflkgjkjf21234dfsglkjhdfgkjhdfkjhgkdfkjhxkbjhxvbkcvjhbckvjbhcvkbhcvkbdfgjdlfkjglkdfjglkdfjlgkjdflgkjdflkgjkjf21234dfsglkjhdfgkjhdfkjhgkdfkjhxkbjhxvbkcvjhbckvjbhcvkbhcvkbdfgjdlfkjglkdfjglkdfjlgkjdflgkjdflkgjkjf21234dfsglkjhdfgkjhdfkjhgkdfkjhxkbjhxvbkcvjhbckvjbhcvkbhcvkbdfgjdlfkjglkdfjglkdfjlgkjdflgkjdflkgjkjf21234dfsglkjhdfgkjhdfkjhgkdfkjhxkbjhxvbkcvjhbckvjbhcvkbhcvkbdfgjdlfkjglkdfjglkdfjlgkjdflgkjdflkgjkjf2";
        token.setFullName(filename);
        String param = tokenMock.getParam(token);

        File file = new File(propConfig.getUploadDir() + "\\BAT-XXX\\batman.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);

        ResponseEntity<String> response = uploadBody(param, null, encodedString);
        assertEquals(FORBIDDEN, response.getStatusCode());
    }

    @Test
    public void upload_as_clob() throws IOException {
        String param = tokenMock.getParam(token);

        File file = new File(propConfig.getUploadDir() + "\\BAT-XXX\\batman.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);

        ResponseEntity<String> response = uploadBody(param, null, encodedString);
        assertEquals(CREATED, response.getStatusCode());
    }

    @Test
    public void upload_as_clob1() throws IOException {
        token.setActionType(UPLOAD);
        token.setFullName("batman.jpg");
        String param = tokenMock.getParam(token);

        File file = new File(propConfig.getUploadDir() + "\\BAT-XXX\\batman.jpg");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        FileAsJsonReqDto dto = new FileAsJsonReqDto();
        dto.setFilebody(encodedString);
        dto.setParam("pAqLsB0x/8ePT7b6KsYNZHXADuzewj7OLvCjYuL6AoTXWy+etpmQEKHszQ5DCI1ebkKRUrj1Hr4SjStDX07hkAr88QPLukuX1d7MnQ+RMYbt6Sz9LdH9+4G6gZ9+fNJ6pkfENi9ZNc/68mt0C40LL5dMUwO1b5R78jO10FxVpyOyEtOHsvP6dg==");
        mapperService.encode(dto);

        ResponseEntity<String> response = uploadJsonBody(param, mapperService.encode(dto));
        assertEquals(CREATED, response.getStatusCode());
    }

    @Test
    public void upload_as_clob_15Mb_OK() throws IOException {
        token.setFromServer("MIN");
        token.setActionType(UPLOAD);
        token.setFullName("mvn.7z");
        String param = tokenMock.getParam(token);

        File file = new File(propConfig.getUploadDir() + "mvn.7z");
        byte[] fileContent = FileUtils.readFileToByteArray(file);
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        FileAsJsonReqDto dto = new FileAsJsonReqDto();
        dto.setFilebody(encodedString);
        dto.setParam("Fpumu+X0wyn6G0ixUZdVvbL61nimojVMnqp7KvB3fwtNFo6DeFR9UiR5IIzJRUgcPZi42cSek2TV0DdEOlF9U4wh2b+dbOXmu69Yko8AiWnGrz0Jzi38SbWp0q69GRPJDGkgzaZyqMKqD8QPA6Hq0FQW6SLw17gnL2+ajonJ58YjAK4X/1uMIXm0lwKhx44mLwWmirSeDhc=");
        mapperService.encode(dto);

        ResponseEntity<String> response = uploadJsonBody(param, mapperService.encode(dto));
        assertEquals(CREATED, response.getStatusCode());
    }
}