package com.sportmaster.eafileserver;

import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.NlayerDirectoryManagementService;
import com.sportmaster.eafileserver.utils.EafsUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations = "classpath:test.properties")
public class CommonTest {
    @Autowired
    private JsonMapperService mapper;
    @Autowired
    private NlayerDirectoryManagementService dirService;
    @Autowired
    private DataSource dataSource;

    @Test
    public void jsonSerDeserLocalDateTile_OK() {
        LoggerDto req = new LoggerDto();
        req.setUsername("drew");
        req.setDateFrom(nowDateTimeWithoutMills());

        String json = mapper.encode(req);
        LoggerDto decode = (LoggerDto) mapper.decode(json, LoggerDto.class);
        assertNotNull(decode);
        assertEquals(req.getDateFrom(), decode.getDateFrom());
    }

    @Test
    public void parseNlayer() {
        String s = "ea-file-daasd-server-ZYSEFK-1583413242877";
        String withoutNlayer = "ea-file-daasd-server-1583413242877";
        String layerParam = "ZYSEFK";

        String param = nLayerGetParam(s);
        assertEquals("ZYSEFK", param);

        String folder = nLayerGetFolder(s);
        assertEquals("ea-file-daasd-server-1583413242877", folder);

        String added = nLayerAdd(withoutNlayer, layerParam);
        assertEquals(s, added);

        assertTrue(isNlayer(s));
        assertFalse(isNlayer(withoutNlayer));
    }

    @Test
    public void nowLocalDateTimeMillsIsNUll_OK() {
        LocalDateTime localDateTime = nowDateTimeWithoutMills();
        assertEquals(0, localDateTime.getNano());
    }

    @Test
    public void zoneID_OK() {
        LocalDateTime localDateTime = nowGreenwichDateTimeWithoutMills();
        assertEquals(0, localDateTime.getNano());
    }

    @Test
    public void abc2dex2abc_ok() {
        String ss = "FGG";
        int i = dirService.abc2Dec(ss);
        String s = dirService.dec2Abc(i + 1);
        assertEquals(s, "AAAFGH");
    }

    @Test
    public void getNlayerPrefix2() {
        String nlayerPrefix = dirService.createStructureAndGetParam();
        assertTrue(nlayerPrefix.length() > 0);
    }

    @Test
    public void dateTimeErrorRespFormatter_OK() {
        DateTimeFormatter dateTimeErrorRespFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        String dt = "2019-08-15T06:06:02.551+0000".substring(0, 19);
        LocalDateTime parsed = LocalDateTime.parse(dt, dateTimeErrorRespFormatter);
        assertNotNull(parsed);
    }

   /* @Test
    public void t1() {
        List<String> s = new ArrayList<>();
        s.

    }*/
}
