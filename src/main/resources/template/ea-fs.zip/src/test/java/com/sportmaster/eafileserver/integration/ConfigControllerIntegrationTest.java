package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.integration.mock.ConfigFileMock;
import com.sportmaster.eafileserver.integration.mock.TokenMock;
import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.service.ConfigService;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.SecurityService;
import com.sportmaster.eafileserver.utils.ServletUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.nio.charset.StandardCharsets;

import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:test.properties")
public class ConfigControllerIntegrationTest {
    @Autowired
    private TestRestTemplate restTemplate;
    @Autowired
    private TokenMock tokenMock;
    @Autowired
    private ConfigFileMock configMock;
    @Autowired
    private ConfigService configService;
    @Autowired
    private JsonMapperService mapper;
    @Autowired
    private SecurityService securityService;

    @Test
    public void getConfigTest_Ok() {
        String param = tokenMock.getParam(CONFIG_GET);
        String response = this.restTemplate.getForObject(ServletUtils.ENTRY_POINT + "?param=" + param, String.class);
        ConfigFile decode = (ConfigFile) mapper.decode(response, ConfigFile.class);
        assertNotNull(decode);
        assertNotNull(decode.getServername());
    }

    @Test
    public void postConfigTest_Ok() {
        ResponseEntity<String> response = uploadBody(tokenMock.getParam(CONFIG_POST), configMock.getValidConfigFile());
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void postConfigTest_Fail2() {
        ConfigFile cf = configMock.getValidConfigFile();
        cf.setServername(null);

        ResponseEntity<String> response = uploadBody(tokenMock.getParam(CONFIG_POST), cf);
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    @Ignore
    public void restart() {
        String param = tokenMock.getParam(RESTART_SERVER);
        ResponseEntity<String> response = this.restTemplate.getForEntity(ServletUtils.ENTRY_POINT + "?param=" + param, String.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    private ResponseEntity<String> uploadBody(String param, ConfigFile cf) {
        byte[] configFile = mapper.encode(cf).getBytes(StandardCharsets.UTF_8);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        ContentDisposition contentDisposition = ContentDisposition
                .builder("form-data")
                .name("file")
                .filename("config.json")
                .build();
        MultiValueMap<String, String> fileMap = new LinkedMultiValueMap<>();
        fileMap.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString());

        HttpEntity<byte[]> fileEntity = new HttpEntity<>(configFile, fileMap);
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileEntity);

        HttpEntity<MultiValueMap<String, Object>> requestEntity =
                new HttpEntity<>(body, headers);

        return restTemplate.exchange(
                ServletUtils.ENTRY_POINT + "?param=" + param, HttpMethod.POST, requestEntity, String.class);
    }
}