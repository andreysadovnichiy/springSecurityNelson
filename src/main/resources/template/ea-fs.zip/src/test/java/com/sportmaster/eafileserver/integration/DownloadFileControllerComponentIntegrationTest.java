package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static com.sportmaster.eafileserver.utils.EafsUtils.nowDateTimeWithoutMills;
import static org.junit.Assert.*;
import static org.springframework.http.HttpStatus.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:test.properties")
public class DownloadFileControllerComponentIntegrationTest extends BaseFileControllerIntegrationTest {
    private Token token;

    @Before
    public void init() {
        token = tokenMock.getToken(ActionTypeEnum.DOWNLOAD);

        token.setFileId("_BAT-1571642406245");
        token.setFromServer("SEU1");
        token.setFullName("__lift.txt");

//        token.setFullName("__lift.txt");
//        token.setFileId("SEU1-XXX");
//        token.setFromServer("SEU1");
    }

    @Test
    public void download_OK() {
        String param = tokenMock.getParam(token);

        ResponseEntity response = downloadBody(param);
        assertTrue(response.getBody() != null && ((byte[]) response.getBody()).length > 0);
        assertEquals(OK, response.getStatusCode());
    }

    @Test
    public void download_NLayer_OK() {
        token.setFileId("_BAT-AAAAAA-1571642406245");
        token.setFullName("_batman.jpg");
        String param = tokenMock.getParam(token);

        ResponseEntity response = downloadBody(param);
        assertTrue(response.getBody() != null && ((byte[]) response.getBody()).length > 0);
        assertEquals(OK, response.getStatusCode());
    }

    @Test
    public void download_NLayer_Fail() {
        token.setFileId("SEU1-ZYdZJ-XXX");
        token.setFullName("batman.jpg");
        String param = tokenMock.getParam(token);

        ResponseEntity response = downloadBody(param);
        assertNull(response.getBody());
        assertEquals(NOT_ACCEPTABLE, response.getStatusCode());
    }

    @Test
    public void download_Param_FAIL() {
        String param = "Hello world";
        ResponseEntity response = downloadBody(param);
        assertEquals(NOT_ACCEPTABLE, response.getStatusCode());
    }

    @Test
    public void download_fileId_FileId_FAIL() {
        token.setFileId(null);
        String param = tokenMock.getParam(token);
        ResponseEntity response = downloadBody(param);
        assertEquals(NOT_ACCEPTABLE, response.getStatusCode());
    }

    @Test
    public void download_ExpiredDate_FAIL() {
        token.setDateTo(nowDateTimeWithoutMills().minusDays(1));
        String param = tokenMock.getParam(token);
        ResponseEntity response = downloadBody(param);
        assertEquals(NOT_ACCEPTABLE, response.getStatusCode());
    }
}
