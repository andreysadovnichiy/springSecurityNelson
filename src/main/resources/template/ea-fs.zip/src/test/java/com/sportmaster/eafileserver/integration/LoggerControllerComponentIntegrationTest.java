package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.integration.mock.ConfigFileMock;
import com.sportmaster.eafileserver.integration.mock.TokenMock;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.model.entity.LoggerEntity;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.model.enums.OperationTypeEnum;
import com.sportmaster.eafileserver.model.mapper.LoggerMapper;
import com.sportmaster.eafileserver.repo.LoggerRepository;
import com.sportmaster.eafileserver.service.ConfigService;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.service.SecurityService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.io.UnsupportedEncodingException;
import java.util.List;

import static com.sportmaster.eafileserver.utils.EafsUtils.nowDateTimeWithoutMills;
import static com.sportmaster.eafileserver.utils.ServletUtils.ENTRY_POINT;
import static com.sportmaster.eafileserver.utils.ServletUtils.encodeUri;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:test.properties")
public class LoggerControllerComponentIntegrationTest {
    @Autowired
    private TestRestTemplate restTemplate;
    @Autowired
    private TokenMock tokenMock;
    @Autowired
    private ConfigFileMock configMock;
    @Autowired
    private ConfigService configService;
    @Autowired
    private JsonMapperService mapper;
    @Autowired
    private SecurityService securityService;
    @Autowired
    private LoggerService loggerService;
    @Autowired
    private LoggerMapper loggerMapper;
    @Autowired
    private LoggerRepository repo;


    @Before
    @Transactional
    public void init() {
        repo.deleteAll();
        Token token = new Token();
        token.setUsername("username");
        token.setFromServer("SEU1");
        token.setFullName("__lift.txt");
        token.setFileId("SEU1-XXX");

        loggerService.error("test", token);
        loggerService.success(OperationTypeEnum.UPLOAD, token);
        loggerService.success(OperationTypeEnum.UPLOAD, token);
        loggerService.success(OperationTypeEnum.DOWNLOAD, token);
        loggerService.success(OperationTypeEnum.ADMIN_REQUEST, token);
    }

    @Test
    public void getLogTest_Ok() {
        LoggerDto dto = new LoggerDto();
        dto.setOperation("UPLOAD");
        dto.setStatus("SUCCESS");
        dto.setDateFrom(nowDateTimeWithoutMills().minusDays(1));
        dto.setDateTo(nowDateTimeWithoutMills());

        String param = tokenMock.getParam(ActionTypeEnum.LOG);
        String logUrlParam = loggerMapper.toUrlParam(dto);

        String url = ENTRY_POINT + "?param=" + param + logUrlParam;

        String response = this.restTemplate.getForObject(url, String.class);
        List<LoggerEntity> result = (List<LoggerEntity>) mapper.decode(response, List.class);
        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    public void getLogTestBySql_Ok() throws UnsupportedEncodingException {
        String param = tokenMock.getParam(ActionTypeEnum.LOG);
        String query = "select * from eafslogger where status = 'SUCCESS'";
        String url = ENTRY_POINT + "?param=" + param + "&query=" + encodeUri(query);

        String response = this.restTemplate.getForObject(url, String.class);
        List<LoggerEntity> result = (List<LoggerEntity>) mapper.decode(response, List.class);
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }
}
