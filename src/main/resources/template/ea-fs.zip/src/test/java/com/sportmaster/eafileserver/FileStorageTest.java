package com.sportmaster.eafileserver;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.entity.LoggerEntity;
import com.sportmaster.eafileserver.service.FileStorageService;
import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.utils.EafsUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.sportmaster.eafileserver.utils.EafsUtils.fileidLength;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations = "classpath:test.properties")
public class FileStorageTest {
    @Autowired
    private FileStorageService fileStorageService;

    @Autowired
    private LoggerService loggerService;

    @Test
    public void t2() {
        Token token = new Token();
        token.setFileId("_BAT-1571642406245");
        token.setFromServer("SEU1");
        token.setFullName("__lift.txt");

        Resource resource = fileStorageService.findResourceInStorage(token);
        assertNotNull(resource);
    }

    public void t1_dirs() {
        try (Stream<Path> walk = Files.walk(Paths.get("C:\\dev.src\\test\\"))) {

            List<String> result = walk.filter(Files::isDirectory)
                    .map(Path::toString).collect(Collectors.toList());

            result.forEach(System.out::println);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void t1_files() {
        try (Stream<Path> walk = Files.walk(Paths.get("C:\\dev.src\\test\\"))) {

            List<String> result = walk.filter(Files::isRegularFile)
                    .map(Path::toString).collect(Collectors.toList());

            result.forEach(System.out::println);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
