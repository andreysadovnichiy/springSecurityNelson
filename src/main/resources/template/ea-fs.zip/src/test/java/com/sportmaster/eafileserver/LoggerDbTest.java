package com.sportmaster.eafileserver;

import com.sportmaster.eafileserver.model.entity.LoggerEntity;
import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.OperationTypeEnum;
import com.sportmaster.eafileserver.repo.LoggerRepository;
import com.sportmaster.eafileserver.service.LoggerService;
import org.junit.Before;
import org.junit.Test;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations="classpath:test.properties")
public class LoggerDbTest {
    @Autowired
    private LoggerService loggerService;

    @Autowired
    private LoggerRepository repo;

    @Before
    @Transactional
    public void init() {
        repo.deleteAll();
    }

    @Test
    public void dbExistTest_OK() {
        loggerService.success(OperationTypeEnum.ADMIN_REQUEST, null);
        List<LoggerEntity> all = loggerService.findAll();
        Long id = all.get(0).getId();
        assertTrue(all.size() > 0);
        LoggerEntity one = loggerService.getById(id);
        assertEquals(OperationTypeEnum.ADMIN_REQUEST, one.getOperation());
    }

    private Token getToken() {
        Token token = new Token();
        token.setUsername("username");
        token.setFromServer("SEU1");
        token.setFullName("__lift.txt");
        token.setFileId("SEU1-XXX");
        return token;
    }

    @Test
    public void findBySqlString_OK() {
        Token token = getToken();
        loggerService.error("test", token);
        loggerService.success(OperationTypeEnum.UPLOAD, token);
        loggerService.success(OperationTypeEnum.UPLOAD, token);
        loggerService.success(OperationTypeEnum.DOWNLOAD, token);
        loggerService.success(OperationTypeEnum.ADMIN_REQUEST, token);

        List<LoggerEntity> actual = loggerService.findBySqlString("select * from eafslogger where operation = 'UPLOAD'");
        assertNotNull(actual);
        assertEquals(2, actual.size());
    }

    @Test
    public void findAllByExampleTest_OK() {
        Token token = getToken();
        loggerService.error("test", token);
        loggerService.success(OperationTypeEnum.UPLOAD, token);
        loggerService.success(OperationTypeEnum.UPLOAD, token);
        loggerService.success(OperationTypeEnum.DOWNLOAD, token);
        loggerService.success(OperationTypeEnum.ADMIN_REQUEST, token);

        LoggerDto req = new LoggerDto();
        req.setOperation("UPLOAD");
        req.setStatus("SUCCESS");
        req.setDateFrom(nowDateTimeWithoutMills().minusDays(1));

        List<LoggerEntity> all = loggerService.findAllByExample(req);
        assertEquals(2, all.size());

        req = new LoggerDto();
        req.setMsg("est");
        req.setDateFrom(nowDateTimeWithoutMills().minusDays(1));

        all = loggerService.findAllByExample(req);
        assertEquals(1, all.size());

        req = new LoggerDto();
        req.setUsername(null);
        req.setDateFrom(nowDateTimeWithoutMills().minusDays(1));

        all = loggerService.findAllByExample(req);
        assertEquals(5, all.size());
    }
}
