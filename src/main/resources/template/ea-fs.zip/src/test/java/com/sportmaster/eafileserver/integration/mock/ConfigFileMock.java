package com.sportmaster.eafileserver.integration.mock;

import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.model.Partition;
import com.sportmaster.eafileserver.model.enums.OsEnum;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
@AllArgsConstructor
public class ConfigFileMock {
    private final String SERVERNAME = "EUA1";
    private final String EMAIL_OF_ADMIN = "admin@sportmaster.com";
    private final String SALT = "This is cool salt!";
    private final List<Partition> PARTITIONS = Arrays.asList(new Partition("name1", "type1"), new Partition("name2", "type2"));
    private final OsEnum osEnum = OsEnum.WINDOWS;

    private ConfigFile getValid() {
        ConfigFile cf = new ConfigFile();
        cf.setServername(SERVERNAME);
        cf.setEmailOfAdmin(EMAIL_OF_ADMIN);
        cf.setSalt(SALT);
        cf.setPartitions(PARTITIONS);
        cf.setOs(osEnum);
        return cf;
    }

    public ConfigFile getValidConfigFile() {
        return getValid();
    }
}
