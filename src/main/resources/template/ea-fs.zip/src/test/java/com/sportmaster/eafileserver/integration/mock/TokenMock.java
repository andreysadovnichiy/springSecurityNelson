package com.sportmaster.eafileserver.integration.mock;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.model.enums.HddTypeEnum;
import com.sportmaster.eafileserver.service.SecurityService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.sportmaster.eafileserver.model.enums.HddTypeEnum.TYPE_1;
import static com.sportmaster.eafileserver.utils.EafsUtils.*;

@Service
@AllArgsConstructor
public class TokenMock {
    private final String USERNAME = "testUser";
    private final String FROM_SERVER = "EUA1";
    private final String FULL_NAME = "My test file.file";
    private final String FILE_ID = FROM_SERVER+"007";
    private final HddTypeEnum hddType = TYPE_1;

    private SecurityService securityService;

    private Token getValidToken() {
        Token token = new Token();
        token.setUsername(USERNAME);
        token.setFromServer(FROM_SERVER);
        token.setFullName(FULL_NAME);
        token.setFileId(FILE_ID);
        token.setHddType(hddType);
        token.setDateTo(nowDateTimeWithoutMills().plusYears(101L));
        return token;
    }

    public Token getToken(ActionTypeEnum actionType) {
        Token token = getValidToken();
        token.setActionType(actionType);
        return token;
    }

    public String getParam(ActionTypeEnum actionType) {
        Token token = getValidToken();
        token.setActionType(actionType);
        return securityService.encryptObject(token);
    }

    public String getParam(Token token) {
        return securityService.encryptObject(token);
    }
}
