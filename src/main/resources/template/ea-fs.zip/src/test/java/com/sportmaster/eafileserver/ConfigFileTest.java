package com.sportmaster.eafileserver;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.model.Partition;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations="classpath:test.properties")
public class ConfigFileTest {
    @Autowired
    private ObjectMapper mapper;

    @Test
    public void t1() {
        String actual = null;
        try {
            actual = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(getConfigFile());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        assert actual != null;
        assertTrue(actual.length() > 0);
    }

    private ConfigFile getConfigFile() {
        ConfigFile cf = new ConfigFile();
        cf.setEmailOfAdmin("test@sportmaster.com");
        cf.setSalt("My password");
        cf.setServername("Ser1");
        cf.setPartitions(Arrays.asList(new Partition("name1", "type1"), new Partition("name2", "type2"), new Partition("name3", "type3"), new Partition("name4", "type4")));
        return cf;
    }
}
