package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.integration.mock.TokenMock;
import com.sportmaster.eafileserver.model.dto.response.FindFileRespDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static com.sportmaster.eafileserver.utils.EafsUtils.notNullOrEmpty;
import static com.sportmaster.eafileserver.utils.ServletUtils.ENTRY_POINT;
import static java.util.Collections.singletonList;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.OK;

class BaseFileControllerIntegrationTest {
    @Autowired
    private
    TestRestTemplate restTemplate;
    @Autowired
    TokenMock tokenMock;

    String filename = "test_file";

    ResponseEntity downloadBody(String param) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(singletonList(MediaType.APPLICATION_OCTET_STREAM));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        return restTemplate.exchange(ENTRY_POINT + "?param=" + param, GET, entity, byte[].class);
    }

    ResponseEntity findFile(String param) {
        String url = ENTRY_POINT + "?param=" + param;
        FindFileRespDto response = restTemplate.getForObject(url, FindFileRespDto.class);
        if (response != null && notNullOrEmpty(response.getResourceAvailableOnServers())) {
            return new ResponseEntity<>(response, OK);
        }
        return new ResponseEntity(NOT_FOUND);
    }

    ResponseEntity<String> uploadBody(String param, byte[] bodyAsBytes, String bodyAsString) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, String> fileMap = new LinkedMultiValueMap<>();
        ContentDisposition contentDisposition = ContentDisposition
                .builder("form-data")
                .name("file")
                .filename(filename)
                .build();
        fileMap.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString());
//        HttpEntity<?> fileEntity = new HttpEntity<>(someByteArray, fileMap);
        HttpEntity<?> fileEntity = bodyResolver(fileMap, bodyAsBytes, bodyAsString);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("Bad token decryption!", fileEntity);

        HttpEntity<MultiValueMap<String, Object>> requestEntity =
                new HttpEntity<>(body, headers);

        return restTemplate.exchange(
                ENTRY_POINT + "?param=" + param, POST, requestEntity, String.class);
    }

    private HttpEntity<?> bodyResolver(MultiValueMap<String, String> fileMap, byte[] bodyAsBytes, String bodyAsString) {
        if (bodyAsBytes != null && bodyAsString == null) {
            return new HttpEntity<>(bodyAsBytes, fileMap);
        }
        if (bodyAsBytes == null && bodyAsString != null) {
            return new HttpEntity<>(bodyAsString, fileMap);
        }
        byte[] defaultBody = {12, 21, 33};
        return new HttpEntity<>(defaultBody, fileMap);
    }

    ResponseEntity<String> uploadJsonBody(String param, String bodyAsString) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<String>(bodyAsString, headers);

        String url = ENTRY_POINT + "?param=" + param;
        String resp = restTemplate.postForObject(url, request, String.class);
        return new ResponseEntity<String>(HttpStatus.CREATED);
    }
}
