package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.response.FindFileRespDto;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.FIND_FILE_GLOBAL;
import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.FIND_FILE_LOCAL;
import static com.sportmaster.eafileserver.utils.EafsUtils.nowDateTimeWithoutMills;
import static java.util.Objects.requireNonNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:test.properties")
public class FindFileControllerComponentIntegrationTest extends BaseFileControllerIntegrationTest {
    private Token token;

    @Before
    public void init() {
        token = new Token();
        token.setActionType(FIND_FILE_GLOBAL);
        token.setFullName("__lift.txt");
        token.setFileId("SEU1-XXX");
        token.setFromServer("SEU1");
        token.setUsername("test-user");
        token.setDateTo(nowDateTimeWithoutMills().plusDays(1));
    }

    @Test
    public void findFileLocal_OK() {
        token.setActionType(FIND_FILE_LOCAL);
        ResponseEntity<FindFileRespDto> response = findFile(tokenMock.getParam(token));
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(requireNonNull(response.getBody()).getResourceAvailableOnServers().get(0));
    }

    @Test
    public void findFileGlobal_OK() {
        ResponseEntity<FindFileRespDto> response = findFile(tokenMock.getParam(token));
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(requireNonNull(response.getBody()).getResourceAvailableOnServers().get(0));
    }
}
