package com.sportmaster.eafileserver.integration;

import com.sportmaster.eafileserver.integration.mock.TokenMock;
import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.response.ErrorRespDto;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.service.ConfigService;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.SecurityService;
import com.sportmaster.eafileserver.utils.EafsUtils;
import com.sportmaster.eafileserver.utils.ServletUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:test.properties")
public class EntryPointControllerTest {
    @Autowired
    private TestRestTemplate restTemplate;
    @Autowired
    private TokenMock tokenMock;
    @Autowired
    private ConfigService configService;
    @Autowired
    private JsonMapperService mapper;
    @Autowired
    private SecurityService securityService;

    private Token token;

    @Before
    public void init() {
        token = tokenMock.getToken(ActionTypeEnum.DOWNLOAD);
        token.setFullName("__lift.txt");
        token.setFileId("XXX");
        token.setFromServer("SEU1");
    }

    @Test
    public void getConfigTest_Ok() {
        String param = tokenMock.getParam(ActionTypeEnum.CONFIG_GET);
        String response = this.restTemplate.getForObject(ServletUtils.ENTRY_POINT + "?param=" + param, String.class);
        ConfigFile decode = (ConfigFile) mapper.decode(response, ConfigFile.class);
        assertNotNull(decode);
        assertNotNull(decode.getServername());
    }

    @Test
    public void param_Fail() {
        String param = "Hello world";
        String response = this.restTemplate.getForObject(ServletUtils.ENTRY_POINT + "?param=" + param, String.class);
        ErrorRespDto result = (ErrorRespDto) mapper.decode(response, ErrorRespDto.class);
        assertNotNull(result);
        assertEquals(HttpStatus.FORBIDDEN.value(), result.getStatus());
    }

    @Test
    public void invalidExpiredDate_Fail() {
        Token token = tokenMock.getToken(ActionTypeEnum.CONFIG_POST);
        token.setDateTo(EafsUtils.nowDateTimeWithoutMills().minusDays(1));
        token.setDateFrom(EafsUtils.nowDateTimeWithoutMills().minusDays(2));
        String param = tokenMock.getParam(token);

        String response = this.restTemplate.getForObject(ServletUtils.ENTRY_POINT + "?param=" + param, String.class);
        ErrorRespDto result = (ErrorRespDto) mapper.decode(response, ErrorRespDto.class);

        assertNotNull(result);
        assertEquals(HttpStatus.FORBIDDEN.value(), result.getStatus());
    }
}
