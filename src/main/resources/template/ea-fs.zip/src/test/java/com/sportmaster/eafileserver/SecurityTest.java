package com.sportmaster.eafileserver;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.model.enums.HddTypeEnum;
import com.sportmaster.eafileserver.service.SecurityService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

import static com.sportmaster.eafileserver.utils.EafsUtils.nowDateTimeWithoutMills;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(locations = "classpath:test.properties")
public class SecurityTest {
    @Autowired
    private SecurityService security;
    @Autowired
    private ObjectMapper mapper;

    @Test
    public void encryptDecryptTest_OK() {
        String expected = "import org springframework boot test autoconfigure web servlet AutoConfigureMockMvc";
        String actual = security.decrypt(security.encrypt(expected), false);
        assertEquals(expected, actual);
    }

    @Test
    public void decryptTest_FAIL() {
        String decripted = security.decrypt("123", false);
        assertNull(decripted);
    }

    @Test
    public void parseParamTest_OK() {
        Token token = getToken();
        String input = getTokenAsJson(token);
        System.out.println(input);
        String encript = security.encrypt(input);
        System.out.println(encript);
        String decript = security.decrypt(encript, false);
        System.out.println(decript);
        Token actual = null;
        try {
            actual = mapper.readValue(decript, Token.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertEquals(token, actual);
    }

    private Token getToken() {
        Token param = new Token();
        param.setUsername("Drew");
        param.setFromServer("SEU1");
        param.setActionType(ActionTypeEnum.DOWNLOAD);
        param.setFullName("test_file.css");
        param.setFileId("111");
        param.setDateFrom(nowDateTimeWithoutMills().minusYears(100L));
        param.setDateTo(nowDateTimeWithoutMills().minusYears(99L));
        param.setHddType(HddTypeEnum.TYPE_2);
        return param;
    }

    private String getTokenAsJson(Token token) {
        String input = "";
        try {
            input = mapper.writeValueAsString(token);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return input;
    }
}