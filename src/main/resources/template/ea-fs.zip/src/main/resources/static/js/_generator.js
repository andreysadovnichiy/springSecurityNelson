
$(function () {
  $(document).ready(function() {
    var url = window.location.href;
    var pos = url.indexOf('/generate');
    $('#host').val(url.slice(0, pos));
  });

  var form = function () {
    var obj = {};

    obj.token = {};
    obj.token.username = $('#username').val();
    obj.token.fromServer = $('#fromServer').val();
    obj.token.actionType = $('#actionType').val();
    obj.token.fullName = $('#fullName').val();
    obj.token.fileId = $('#fileId').val();
    obj.token.dateFrom = $('#dateFrom').val();
    obj.token.dateTo = $('#dateTo').val();
    obj.token.hddType = $('#hddType').val();

    obj.logRequest = {};
    obj.logRequest.operation = $('#operation').val();
    obj.logRequest.status = $('#status').val();
    obj.logRequest.username = $('#usernameLog').val();
    obj.logRequest.fromServer = $('#fromServerLog').val();
    obj.logRequest.fileName = $('#fileNameLog').val();
    obj.logRequest.fileId = $('#fileIdLog').val();
    obj.logRequest.dateFrom = $('#dateFromLog').val();
    obj.logRequest.dateTo = $('#dateToLog').val();
    obj.logRequest.msg = $('#msg').val();

    obj.host = $('#host').val();
    return obj;
  };

  $('#logSqlBtn').click(function () {
    $('#logSql').val(encodedLogSql());
  });

  function encodedLogSql() {
      var s = $('#logSql').val();
      return encodeURI(s);
  }

  $('#paramDecompileBtn').click(function () {
    var paramObj = {};
    paramObj["param"] = $('#param').val();
    $.ajax({
          url: '/ea-file-server/generate/parse-param',
          type: "POST",
          data: JSON.stringify(paramObj, false),
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function (data) {
            console.log(data);
            $('#username').val(data.token.username);
            $('#fromServer').val(data.token.fromServer);
            $('#actionType').val(data.token.actionType);
            $('#fullName').val(data.token.fullName);
            $('#fileId').val(data.token.fileId);
            $('#hddType').val(data.token.hddType);
            $('#dateFrom').val(data.token.dateFrom);
            $('#dateTo').val(data.token.dateTo);
          },
          error: function (request, status, error) {
          }
        })
  });

  $('#sendPostFile').click(function () {
    var formData = new FormData();

    var file = singleFileUploadInput.files[0];
    formData.append("file", file);
    let param = $('#param').val();

    var link = "/ea-file-server/process?param=" + param;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", link);
    xhr.onload = function () {
      var response = JSON.parse(xhr.responseText);
      if (xhr.status == 201) {
      } else {
        alert("Some Error Occurred");
      }
    }
    xhr.send(formData);
  });

  $('#sendBtn').click(function () {
    var obj = form();
    $.ajax({
      url: '/ea-file-server/generate',
      type: "POST",
      data: JSON.stringify(obj, false),
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      success: function (data) {
        console.log(data);
        if(obj.token.actionType === 'LOG') {
            data.url += ("&query=" + encodedLogSql());
            console.log(data.url);
        }
        $('#param').val(data.param);
        $('#url').val(data.url);
        $('#url').select();
        document.execCommand("copy");
      },
      error: function (request, status, error) {
      }
    })
  });
});