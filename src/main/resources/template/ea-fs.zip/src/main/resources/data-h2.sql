INSERT INTO eafslogger (id, operation, status)
	VALUES(1, 'UPLOAD', 'SUCCESS');