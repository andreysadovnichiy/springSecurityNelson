package com.sportmaster.eafileserver.filter;

import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import com.sportmaster.eafileserver.service.SecurityService;
import lombok.AllArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//@Component
@Order(20)
@AllArgsConstructor
public class RedirectFilter extends OncePerRequestFilter {
    private RequestScopeHolder requestScopeHolder;
    private SecurityService security;
    private JsonMapperService mapperService;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        return true;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws ServletException, IOException {
        resp.sendRedirect("http://dda-test.gksm.local/ea-file-server/process?param=XPvTFCxRhMDN2q8hGaCzp2Js0/FuIw/Wu6bN4VeIJf6dpJIrSZBkQ91PukQVz1hbHG0gsAkSRaHClJWRm9l7x2eH8vxIuasi2S8DxIyUp8wxxutGYpjZvNniv0fJf4Mjnml4VOa0//0dR8t7WFzBq3W2rdYAIi5t2mjq9gkF6fvgyMgSiuNIdw==");

        System.out.println(resp);
    }
}
