package com.sportmaster.eafileserver.model.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Objects;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoggerDto {
    private String operation;
    private String status;
    private String username;
    private String fromServer;
    private String fileName;
    private String fileId;

    @JsonDeserialize(using = com.sportmaster.eafileserver.model.custom_json.LocalDateTimeDeserializer.class)
    @JsonSerialize(using = com.sportmaster.eafileserver.model.custom_json.LocalDateTimeSerializer.class)
    private LocalDateTime dateFrom;

    @JsonDeserialize(using = com.sportmaster.eafileserver.model.custom_json.LocalDateTimeDeserializer.class)
    @JsonSerialize(using = com.sportmaster.eafileserver.model.custom_json.LocalDateTimeSerializer.class)
    private LocalDateTime dateTo;
    private String msg;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LoggerDto)) return false;
        LoggerDto request = (LoggerDto) o;
        return Objects.equals(getOperation(), request.getOperation()) &&
                Objects.equals(getStatus(), request.getStatus()) &&
                Objects.equals(getUsername(), request.getUsername()) &&
                Objects.equals(getFromServer(), request.getFromServer()) &&
                Objects.equals(getFileName(), request.getFileName()) &&
                Objects.equals(getFileId(), request.getFileId()) &&
                Objects.equals(getDateFrom(), request.getDateFrom()) &&
                Objects.equals(getDateTo(), request.getDateTo()) &&
                Objects.equals(getMsg(), request.getMsg());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOperation(), getStatus(), getUsername(), getFromServer(), getFileName(), getFileId(), getDateFrom(), getDateTo(), getMsg());
    }
}
