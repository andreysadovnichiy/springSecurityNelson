package com.sportmaster.eafileserver.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

public enum OperStatusEnum {
    SUCCESS,
    ERROR;

    private static Map<String, OperStatusEnum> namesEnum = new HashMap<>();

    static {
        namesEnum.put("SUCCESS", OperStatusEnum.SUCCESS);
        namesEnum.put("ERROR", OperStatusEnum.ERROR);
    }

    @JsonCreator
    public static OperStatusEnum forValue(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return namesEnum.get(value.toUpperCase());
    }

    @JsonValue
    public String toValue() {
        return this.toString();
    }
}
