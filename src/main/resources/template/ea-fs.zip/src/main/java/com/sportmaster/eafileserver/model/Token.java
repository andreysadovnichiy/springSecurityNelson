package com.sportmaster.eafileserver.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sportmaster.eafileserver.model.custom_json.LocalDateTimeDeserializer;
import com.sportmaster.eafileserver.model.custom_json.LocalDateTimeSerializer;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.model.enums.HddTypeEnum;
import lombok.Data;

import javax.validation.constraints.Size;
import java.time.LocalDateTime;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;

@Data
@JsonPropertyOrder({
            "username",
            "fromServer",
            "actionType",
            "fullName",
            "fileId",
            "dateFrom",
            "dateTo",
            "hddType"
        })
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Token {
    @Size(max = usernameLength, message = "Field username must be from 1 up to " + usernameLength)
    private String username;
    @Size(max = serverfromLength, message = "Field fromServer must be from 1 up to " + serverfromLength)
    private String fromServer;
    private ActionTypeEnum actionType;
    @Size(max = filenameLength, message = "Field fullName must be from 1 up to " + filenameLength)
    private String fullName;
    @Size(max = fileidLength, message = "Field fileId must be from 1 up to " + fileidLength)
    private String fileId;
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime dateFrom;
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime dateTo;
    private HddTypeEnum hddType;
}
