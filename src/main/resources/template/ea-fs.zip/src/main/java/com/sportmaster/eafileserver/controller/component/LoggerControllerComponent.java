package com.sportmaster.eafileserver.controller.component;

import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.service.LoggerService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import static org.springframework.http.HttpStatus.OK;

@Component
@AllArgsConstructor
public class LoggerControllerComponent {
    private LoggerService log;

    public ResponseEntity<?> getLogByParam(LoggerDto loggerDto) {
        return new ResponseEntity<>(log.findAllByExample(loggerDto), OK);
    }

    public ResponseEntity<?> getLogByQuery(String query) {
        return new ResponseEntity<>(log.findBySqlString(query), OK);
    }
}
