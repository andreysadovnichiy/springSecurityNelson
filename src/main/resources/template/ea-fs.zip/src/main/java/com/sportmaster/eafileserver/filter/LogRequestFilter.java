package com.sportmaster.eafileserver.filter;

import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import com.sportmaster.eafileserver.service.SecurityService;
import lombok.AllArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.sportmaster.eafileserver.utils.ServletUtils.notApplyFilterTo;

@Component
@Order(999)
@AllArgsConstructor
public class LogRequestFilter extends OncePerRequestFilter {
    private RequestScopeHolder requestScopeHolder;
    private SecurityService security;
    private LoggerService loggerService;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        return notApplyFilterTo.stream()
                .anyMatch(s -> req.getServletPath().contains(s));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws ServletException, IOException {
        boolean isDeepLogActive = false;
        if (isDeepLogActive) {
            String token = requestScopeHolder.getToken().toString();
            String url = req.getRequestURL().toString();
            String contentType = req.getContentType();

            String result = token + "\n  "
                    + url + "\n  "
                    + contentType + "\n  ";

            if (result.length() >= 250) {
                result = result.substring(0, 250);
            }
            loggerService.deepLog(result);
        }
        chain.doFilter(req, resp);
    }
}
