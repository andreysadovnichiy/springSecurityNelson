package com.sportmaster.eafileserver.service;

import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.model.exception.TokenException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;
import static java.lang.Math.pow;
import static java.util.Arrays.asList;
import static java.util.Collections.reverse;

@Service
@AllArgsConstructor
public class NlayerDirectoryManagementService {
    private PropConfig propConfig;
    private LoggerService log;
    private RequestScopeHolder tokenHolder;

    public String dec2Abc(int dex) {
        if (dex < 0) {
            log.error("Invalid N-Layer directory decryption!", tokenHolder.getToken());
            throw new FileStorageException("Invalid N-Layer directory decryption!");
        }
        List<Character> result = new ArrayList<>();
        while (dex != 0) {
            result.add((char) ((dex % 26) + 65));
            dex /= 26;
        }
        int nlayerLen = 6;
        while (result.size() < nlayerLen) {
            result.add('A');
        }
        reverse(result);
        return result.stream().map(String::valueOf).collect(Collectors.joining());
    }

    public int abc2Dec(String s) {
        if (nullOrEmpty(s) || !isAbc(s)) {
            String errMsg = "Invalid N-Layer directory decryption! param is - " + s;
            log.error(errMsg, tokenHolder.getToken());
            throw new FileStorageException(errMsg);
        }
        s = s.toUpperCase();
        int result = 0;
        int power = s.length() - 1;
        int pos = 0;
        while (pos != s.length()) {
            result += (((int) s.charAt(pos) - 65) * pow(26, power));
            pos++;
            power--;
        }
        return result;
    }

    private String getLastDirByAbc(String path) {
        return getFilesInDir(path).stream()
                .filter(File::isDirectory)
                .map(File::getName)
                .filter(s -> s.length() == 2 && isAbc(s))
                .map(String::toUpperCase)
                .sorted()
                .reduce("AA", (a, b) -> b);
    }

    public String createStructureAndGetParam() {
        String path = propConfig.getUploadDir();

        String first = getLastDirByAbc(path);
        String second = getLastDirByAbc(path + "/" + first);
        String third = getLastDirByAbc(path + "/" + first + "/" + second);

        String param = first + second + third;
        if (checkIfDirIsFull(param)) {
            int i = abc2Dec(param);
            param = dec2Abc(i + 1);
            if (!isNlayerParamValid(param)) {
                log.error("Nlayer param length exceeded", tokenHolder.getToken());
                throw new TokenException("Nlayer param length exceeded");
            }
        }
        createDirsStructure(param);
        return param;
    }

    private boolean checkIfDirIsFull(String param) {
        return getFilesInDir(getTargetDir(param)).size() >= propConfig.getNlayerTargetDirCapacity();
    }

    private void createDirsStructure(String param) {
        List<String> dirs = parseParamToDirs(param);
        String path = propConfig.getUploadDir() + "/" + dirs.get(0);
        createDirIfAbsent(path);
        path += ("/" + dirs.get(1));
        createDirIfAbsent(path);
        path += ("/" + dirs.get(2));
        createDirIfAbsent(path);
    }

    String getTargetDir(String param) {
        List<String> dirs = parseParamToDirs(param);
        return propConfig.getUploadDir() + "/" + dirs.get(0) + "/" + dirs.get(1) + "/" + dirs.get(2);
    }

    private List<String> parseParamToDirs(String param) {
        if (!isNlayerParamValid(param)) {
            String errMsg = "NLayer parameter for subdirectories must be 6 latin symbols : " + param;
            log.error(errMsg, tokenHolder.getToken());
            throw new TokenException(errMsg);
        }
        return asList(param.substring(0, 2), param.substring(2, 4), param.substring(4, 6));
    }

    private void createDirIfAbsent(String path) {
        File f = new File(path);
        if (!f.isDirectory()) {
            if (!f.mkdirs()) {
                String errMsg = "Could not create dir : " + path;
                log.error(errMsg, tokenHolder.getToken());
                throw new FileStorageException(errMsg);
            }
        }
    }
}