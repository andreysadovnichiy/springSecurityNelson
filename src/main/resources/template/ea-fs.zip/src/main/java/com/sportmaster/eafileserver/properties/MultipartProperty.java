package com.sportmaster.eafileserver.properties;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.ApplicationScope;

import java.util.HashMap;
import java.util.Map;

@ApplicationScope
@Component
public class MultipartProperty {
//    private String serverUrl = "http://localhost:8080/rmultipart/api/v1/test";
//    private String serverUrl = "http://localhost:8080/api/v1/test";
//    private String serverUrl = "http://sefarm12-test.ords.marathon.mesos.sportmaster.ru/ords/archive_cd/ea/mf";
    public static String SCHEMA = "schema";
    private String INDOC = "indoc";
    private String SCHEMA_INDOC = "http://sefarm12-test.ords.marathon.mesos.sportmaster.ru/ords/indoc/ea/mf";
    private String TEST = "test";
    private String SCHEMA_TEST = "http://sefarm12-test.ords.marathon.mesos.sportmaster.ru/ords/archive_cd/ea/mf";
    private Map<String, String> schemaMap = new HashMap<>();

    public Map<String, String> getSchemaMap() {
        if(schemaMap.isEmpty()){
            schemaMap.put(INDOC, SCHEMA_INDOC);
            schemaMap.put(TEST, SCHEMA_TEST);
        }
        return schemaMap;
    }
}
