package com.sportmaster.eafileserver.filter;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.request.FileAsJsonReqDto;
import com.sportmaster.eafileserver.model.exception.TokenException;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import com.sportmaster.eafileserver.service.SecurityService;
import lombok.AllArgsConstructor;
import org.apache.commons.io.IOUtils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import static com.sportmaster.eafileserver.utils.EafsUtils.notNullOrEmpty;
import static com.sportmaster.eafileserver.utils.ServletUtils.notApplyFilterTo;

@Component
@Order(1)
@AllArgsConstructor
public class ExtractParamFilter extends OncePerRequestFilter {
    private RequestScopeHolder requestScopeHolder;
    private SecurityService security;
    private JsonMapperService mapperService;
    private Validator validator;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        return notApplyFilterTo.stream()
                .anyMatch(s -> req.getServletPath().contains(s));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws ServletException, IOException {
        if (!processJsonBody(req)) {
            Map<String, String[]> map = req.getParameterMap();
            if (map == null || map.get("param") == null) {
                throw new TokenException("Param not found!");
            }

            String[] params = map.get("param");
            if (params == null || params.length != 1) {
                throw new TokenException("Param not found!");
            }

            String decrypted = security.decrypt(params[0], true);
            if (decrypted == null) {
                throw new TokenException("Bad token decryption!");
            }

            Token token = security.parseParams(decrypted);
            if (token == null) {
                throw new TokenException("Broken token!");
            }

            validateTokenFieldLength(token);

            requestScopeHolder.setToken(token);
        }
        chain.doFilter(req, resp);
    }

    private void validateTokenFieldLength(Token token) {
        Set<ConstraintViolation<Token>> errs = validator.validate(token);
        if (!errs.isEmpty()) {
            ConstraintViolation<Token> err = (new ArrayList<>(errs)).get(0);
            throw new TokenException(err.getMessage());
        }
    }

    private boolean processJsonBody(HttpServletRequest req) {
        boolean result = false;
        try {
            String jsonBody = IOUtils.toString(req.getInputStream(), "UTF-8");
            if (notNullOrEmpty(jsonBody)) {
                FileAsJsonReqDto dto = (FileAsJsonReqDto) mapperService.decode(jsonBody, FileAsJsonReqDto.class);
                if (dto != null) {
                    requestScopeHolder.setJsonBodyDto(dto);
                    String decrypt = security.decrypt(dto.getParam(), false);
                    Token token = security.parseParams(decrypt);
                    if (token != null) {
                        requestScopeHolder.setToken(token);
                        result = true;
                    }
                }
            }
        } catch (IOException ignored) {
        }
        return result;
    }
}
