package com.sportmaster.eafileserver.filter.validation;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import lombok.AllArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.support.MultipartFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.LOG;
import static com.sportmaster.eafileserver.utils.EafsUtils.validateTokenFieldsNotNullOrEmpty;
import static com.sportmaster.eafileserver.utils.ServletUtils.notApplyFilterTo;
import static java.util.Arrays.asList;

@Component
@Order(12)
@AllArgsConstructor
public class LogValidateParamFilter extends MultipartFilter {
    private RequestScopeHolder requestScopeHolder;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        return notApplyFilterTo.stream()
                .anyMatch(s -> req.getServletPath().contains(s));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws ServletException, IOException {
        Token token = requestScopeHolder.getToken();

        if (LOG.equals(token.getActionType())) {
            validateTokenFieldsNotNullOrEmpty(token, asList("username", "fromServer"));
        }

        super.doFilterInternal(req, resp, chain);
    }
}
