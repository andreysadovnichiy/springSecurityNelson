package com.sportmaster.eafileserver.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum ContentTypeToShowEnum {
    GIF,
    JPEG,
    PNG,
    TIFF,
    VND,
    PDF;

    private static Map<String, ContentTypeToShowEnum> names = new HashMap<>();
    private static Map<ContentTypeToShowEnum, String> mediaTypes = new HashMap<>();

    static {
        names.put("GIF", ContentTypeToShowEnum.GIF);
        names.put("JPEG", ContentTypeToShowEnum.JPEG);
        names.put("JPG", ContentTypeToShowEnum.JPEG);
        names.put("PNG", ContentTypeToShowEnum.PNG);
        names.put("BMP", ContentTypeToShowEnum.PNG);
        names.put("TIFF", ContentTypeToShowEnum.TIFF);
        names.put("VND", ContentTypeToShowEnum.VND);
        names.put("PDF", ContentTypeToShowEnum.PDF);

        mediaTypes.put(ContentTypeToShowEnum.GIF, "image/gif");
        mediaTypes.put(ContentTypeToShowEnum.JPEG, "image/jpeg");
        mediaTypes.put(ContentTypeToShowEnum.PNG, "image/png");
        mediaTypes.put(ContentTypeToShowEnum.TIFF, "image/tiff");
        mediaTypes.put(ContentTypeToShowEnum.VND, "image/vnd.microsoft.icon");
        mediaTypes.put(ContentTypeToShowEnum.PDF, "application/pdf");
    }

    public static ContentTypeToShowEnum forValue(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return names.get(value.toUpperCase());
    }

    public static String mediaTypeforValue(ContentTypeToShowEnum in) {
        if (in == null) {
            return "application/octet-stream";
        }
        return mediaTypes.get(in);
    }
}
