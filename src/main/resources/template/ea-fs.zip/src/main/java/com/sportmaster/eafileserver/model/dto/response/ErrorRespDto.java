package com.sportmaster.eafileserver.model.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sportmaster.eafileserver.model.custom_json.LocalDateTimeErrorRespDeserializer;
import com.sportmaster.eafileserver.model.custom_json.LocalDateTimeErrorRespSerializer;
import lombok.Data;
import org.springframework.boot.jackson.JsonComponent;

import java.time.LocalDateTime;

@Data
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorRespDto {
    @JsonDeserialize(using = LocalDateTimeErrorRespDeserializer.class)
    @JsonSerialize(using = LocalDateTimeErrorRespSerializer.class)
    private LocalDateTime timestamp;
    private int status;
    private String error;
    private String message;
    private String path;
}
