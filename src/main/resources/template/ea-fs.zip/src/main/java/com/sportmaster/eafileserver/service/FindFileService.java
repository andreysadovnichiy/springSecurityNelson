package com.sportmaster.eafileserver.service;

import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.dto.response.FindFileRespDto;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.utils.ServletUtils;
import lombok.AllArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.FIND_FILE_GLOBAL;
import static com.sportmaster.eafileserver.model.enums.ActionTypeEnum.FIND_FILE_LOCAL;
import static com.sportmaster.eafileserver.utils.EafsUtils.notNullOrEmpty;

@Service
@AllArgsConstructor
public class FindFileService {
    private SecurityService securityService;
    private RestTemplate restTemplate;
    private FileStorageService fileStorageService;
    private PropConfig propConfig;
    private ConfigService configService;

    public List<String> findFileGlobal(String fileId, String fullName) {
        Map<String, String> servers = propConfig.getServersToFind();
        List<String> urls = new ArrayList<>();
        String fromServer = configService.getConfig().getServername().trim().toLowerCase();
        servers.remove(fromServer);

        findFileLocal(fileId, fullName, urls);

        Token token = getToken(fileId, fullName, fromServer, FIND_FILE_GLOBAL);
        String param = securityService.encryptObject(token);

        servers.forEach((k, v) -> {
            String url = v + ServletUtils.ENTRY_POINT + "?param=" + param;
            try {
                FindFileRespDto result = restTemplate.getForObject(url, FindFileRespDto.class);
                assert result != null;
                if (notNullOrEmpty(result.getResourceAvailableOnServers())) {
                    urls.addAll(result.getResourceAvailableOnServers());
                }
            } catch (Exception ignored) {
            }
        });
        return urls;
    }

    private void findFileLocal(String fileId, String fullName, List<String> urls) {
        String fromServer = configService.getConfig().getServername().trim().toLowerCase();
        Token token = getToken(fileId, fullName, fromServer, FIND_FILE_LOCAL);
        Resource resource = fileStorageService.findResourceInStorage(token);
        if (resource != null && resource.exists()) {
            urls.add(fromServer);
        }
    }

    public boolean isFileLocalExists(String fileId, String fullName) {
        boolean result = false;
        String fromServer = configService.getConfig().getServername().trim().toLowerCase();
        Token token = getToken(fileId, fullName, fromServer, FIND_FILE_LOCAL);
        Resource resource = fileStorageService.findResourceInStorage(token);
        if (resource != null && resource.exists()) {
            result = true;
        }
        return result;
    }

    private Token getToken(String fileId, String fullName, String fromServer, ActionTypeEnum actionType) {
        Token token = new Token();
        token.setFullName(fullName);
        token.setFileId(fileId);
        token.setDateTo(LocalDateTime.now().plusDays(1L));
        token.setActionType(actionType);
        token.setUsername("find_file");
        token.setFromServer(fromServer);
        return token;
    }
}
