package com.sportmaster.eafileserver.model.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GenerateRespDto {
    private String url;
    private String param;
}