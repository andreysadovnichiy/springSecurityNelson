package com.sportmaster.eafileserver.controller;

import com.sportmaster.eafileserver.controller.component.ConfigControllerComponent;
import com.sportmaster.eafileserver.controller.component.FileControllerComponent;
import com.sportmaster.eafileserver.controller.component.LoggerControllerComponent;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.request.FileAsJsonReqDto;
import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import static com.sportmaster.eafileserver.utils.EafsUtils.notNullOrEmpty;
import static com.sportmaster.eafileserver.utils.ServletUtils.*;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.OK;

@RestController
@AllArgsConstructor
public class EntryPointController {
    private RequestScopeHolder requestScopeHolder;
    private final ConfigControllerComponent configController;
    private final FileControllerComponent fileController;
    private final LoggerControllerComponent loggerController;
    private final LoggerService log;

    @GetMapping(ENTRY_POINT_STREAM)
    public ResponseEntity<StreamingResponseBody> download(final HttpServletResponse response) throws UnsupportedEncodingException {
        Token token = requestScopeHolder.getToken();
        ResponseEntity<StreamingResponseBody> streamResponse = fileController.streamingDownload(response, token);
        return new ResponseEntity(streamResponse, OK);
    }

    @GetMapping(ENTRY_POINT)
    public ResponseEntity getProcess(@RequestParam(value = "query", required = false) String query) throws UnsupportedEncodingException {
        Token token = requestScopeHolder.getToken();
        ResponseEntity<?> response;
        switch (token.getActionType()) {
            case RESTART_SERVER: {
                response = configController.restart();
                break;
            }
            case CONFIG_GET: {
                response = configController.getConfig();
                break;
            }
            case DOWNLOAD: {
                response = fileController.download();
                break;
            }
            case LOG: {
                if (notNullOrEmpty(query)) {
                    response = loggerController.getLogByQuery(decodeUri(query));
                } else {
                    response = loggerController.getLogByParam(requestScopeHolder.getLoggerDto());
                }
                break;
            }
            case FIND_FILE_GLOBAL: {
                response = fileController.findFileGlobal();
                break;
            }
            case FIND_FILE_LOCAL: {
                response = fileController.findFileLocal();
                break;
            }
            default: {
                log.error("Could not resolve path!", requestScopeHolder.getToken());
                response = new ResponseEntity(NOT_FOUND);
            }
        }
        return response;
    }

    @PostMapping(ENTRY_POINT)
    public ResponseEntity postProcessUpload(@RequestPart(value = "file", required = false) MultipartFile multipartFile) throws IOException {
        ResponseEntity response;
        switch (requestScopeHolder.getToken().getActionType()) {
            case CONFIG_POST: {
                response = configController.postConfig(multipartFile);
                break;
            }
            case UPLOAD: {
                FileAsJsonReqDto jsonBody = requestScopeHolder.getJsonBodyDto();
                if (jsonBody != null) {
                    response = fileController.upload(jsonBody.getFilebody());
                } else if (multipartFile != null) {
                    response = fileController.upload(multipartFile);
                } else {
                    log.error("Could not resolve attached file!", requestScopeHolder.getToken());
                    response = new ResponseEntity(NOT_FOUND);
                }
                break;
            }
            default: {
                log.error("Could not resolve path!", requestScopeHolder.getToken());
                response = new ResponseEntity(NOT_FOUND);
            }
        }
        return response;
    }
}
