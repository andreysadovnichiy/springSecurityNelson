package com.sportmaster.eafileserver.utils;

import com.sportmaster.eafileserver.model.enums.ContentTypeToShowEnum;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;

public class ServletUtils {
    public static final List<String> notApplyFilterTo = Arrays.asList("/start", "/error", "/css", "/js", "/favicon.ico", "/generate", "/h2-console,", "/api/v1");

    public static final String ENTRY_POINT = "/process";
    public static final String ENTRY_POINT2 = "/process2";

    public static final String ENTRY_POINT_STREAM = "/process/stream";

    public static final String GENERATE_PARAM = "/generate/param";

    public static final String GENERATE_DIR_LIST = "/generate/dir-list";

    public static final String GENERATE_GET_PATH = "/generate/get-path";

    public static final String PARSE_PARAM = "/generate/parse-param";

    public static final String GENERATE = "/generate";

    public static String decodeUri(String uri) throws UnsupportedEncodingException {
        return URLDecoder.decode(uri, "UTF-8");
    }

    public static String encodeUri(String uri) throws UnsupportedEncodingException {
        return URLEncoder.encode(uri, "UTF-8");
    }

    public static String getContentDepositionByFilename(String filename) {
        if (ContentTypeToShowEnum.forValue(getFileExtension(filename)) != null) {
            return "inline";
        }
        return "attachment";
    }

    public static String getContentTypeByFilename(String filename) {
        ContentTypeToShowEnum contentType = ContentTypeToShowEnum.forValue(getFileExtension(filename));
        return ContentTypeToShowEnum.mediaTypeforValue(contentType);
    }

    private static String getFileExtension(String filename) {
        int pos = filename.lastIndexOf(".");
        String ext = null;
        if (pos > 0) {
            ext = filename.substring(pos + 1);
        }
        return ext;
    }
}
