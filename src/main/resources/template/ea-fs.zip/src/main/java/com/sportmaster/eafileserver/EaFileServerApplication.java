package com.sportmaster.eafileserver;

import com.sportmaster.eafileserver.config_init.PropConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import static org.springframework.boot.SpringApplication.run;

@SpringBootApplication
@EnableConfigurationProperties({
        PropConfig.class
})
public class EaFileServerApplication {
    public static void main(String[] args) {
        run(EaFileServerApplication.class, args);
    }
}