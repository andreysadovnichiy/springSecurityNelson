package com.sportmaster.eafileserver.controller.exception_handler;

import com.sportmaster.eafileserver.model.exception.ConfigException;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.model.exception.TokenException;
import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import lombok.AllArgsConstructor;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import static org.springframework.http.HttpStatus.*;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
@AllArgsConstructor
public class ExceptionController extends ResponseEntityExceptionHandler {
    private LoggerService log;
    private RequestScopeHolder tokenHolder;

    @ExceptionHandler({TokenException.class})
    public final ResponseStatusException badTokenExceptionHandler(RuntimeException ex) {
        return baseHandler(FORBIDDEN, ex);
    }

    @ExceptionHandler({FileStorageException.class})
    public final ResponseStatusException fileStorageExceptionHandler(RuntimeException ex) {
            return baseHandler(NOT_FOUND, ex);
    }

    @ExceptionHandler({ConfigException.class})
    public final ResponseStatusException configExceptionHandler(RuntimeException ex) {
        return baseHandler(CONFLICT, ex);
    }

    @ExceptionHandler(value = {RuntimeException.class})
    public final ResponseStatusException noHandlerFoundException(Exception ex) {
        log.error(ex.getMessage(), tokenHolder.getToken());
        return baseHandler(ex);
    }

    private ResponseStatusException baseHandler(HttpStatus status, Exception ex) throws RuntimeException {
        log.error(ex.getMessage(), tokenHolder.getToken());
        throw new ResponseStatusException(status, ex.getMessage());
    }

    private ResponseStatusException baseHandler(Exception ex) throws RuntimeException {
        log.error(ex.getMessage(), tokenHolder.getToken());
        throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Unexpected error", ex);
    }
}