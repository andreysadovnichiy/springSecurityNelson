package com.sportmaster.eafileserver.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sportmaster.eafileserver.model.Token;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class SecurityService {
    private EncryptorResolverService stringEncryptor;
    private LoggerService log;
    private ObjectMapper mapper;
    private RequestScopeHolder tokenHolder;

    public String encrypt(String input) {
        return stringEncryptor.getEncryptor().encrypt(input);
    }

    public String encryptObject(Object obj) {
        String encrypt = null;
        try {
            encrypt = encrypt(mapper.writeValueAsString(obj));
        } catch (Exception e) {
            log.error("Ecrypt error!", tokenHolder.getToken());
        }
        return encrypt;
    }

    public String decrypt(String input, boolean autoFixSpaces) {
        String decrypted = null;
        try {
            if (autoFixSpaces) {
                input = input.replace(' ', '+');
            }
            decrypted = stringEncryptor.getEncryptor().decrypt(input);
        } catch (Exception e) {
            log.error("Decrypt error!", tokenHolder.getToken());
        }
        return decrypted;
    }

    public Token parseParams(String param) {
        Token token = null;
        try {
            token = mapper.readValue(param, Token.class);
        } catch (Exception e) {
            log.error("Parse param error!", tokenHolder.getToken());
        }
        return token;
    }
}
