package com.sportmaster.eafileserver.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import org.springframework.stereotype.Service;

import java.io.IOException;

import static com.sportmaster.eafileserver.utils.EafsUtils.nullOrEmpty;
import static java.lang.String.join;
import static java.nio.file.Files.readAllLines;
import static java.nio.file.Files.write;

@Service("configService")
public class ConfigService {
    private PropConfig propConfig;
    private ObjectMapper mapper;
    private ConfigFile config;
    private boolean isConfigValid;

    public ConfigService(PropConfig propConfig, ObjectMapper mapper) {
        this.propConfig = propConfig;
        this.mapper = mapper;
    }

    public void saveConfig(ConfigFile file) {
        if (!validateConfig(file)) {
            throw new FileStorageException("Could not validate new config!");
        }
        try {
            String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(file);
            write(propConfig.getSysConfFile(), json.getBytes());
            config = file;
            isConfigValid = true;
        } catch (IOException e) {
            throw new FileStorageException("Could not update config file");
        }
    }

    public void loadConfig() {
        isConfigValid = true;
        try {
            String json = join("", readAllLines(propConfig.getSysConfFile()));
            ConfigFile cf = mapper.readValue(json, ConfigFile.class);
            if (nullOrEmpty(cf.getServername()) || nullOrEmpty(cf.getSalt())) {
                isConfigValid = false;
            } else {
                this.config = cf;
            }
        } catch (IOException e) {
            isConfigValid = false;
        }
    }

    public boolean validateConfig(ConfigFile cf) {
        boolean isValid = true;
        if (cf == null) {
            isValid = false;
        } else if (nullOrEmpty(cf.getServername()) || nullOrEmpty(cf.getSalt())) {
            isValid = false;
        }
        return isValid;
    }

    public boolean isConfigValid() {
        return isConfigValid;
    }

    public ConfigFile getConfig() {
        return config;
    }
}
