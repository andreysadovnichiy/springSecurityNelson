package com.sportmaster.eafileserver.service;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.jasypt.salt.StringFixedSaltGenerator;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class EncryptorResolverService {
    private final ConfigurableApplicationContext ctx;
    private final String pass = "SuperPasw20190410";
    private StringEncryptor encryptor;

    public EncryptorResolverService(ConfigurableApplicationContext ctx) {
        this.ctx = ctx;
    }

    public void refresh() {
        this.encryptor = getStringEncryptor();
    }

    StringEncryptor getEncryptor() {
        if (encryptor == null) {
            refresh();
        }
        return encryptor;
    }

    private StringEncryptor getStringEncryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig cfg = new SimpleStringPBEConfig();
        cfg.setPassword(pass);
        cfg.setAlgorithm("PBEWithMD5AndDES");
        cfg.setKeyObtentionIterations("173");
        cfg.setPoolSize("1");
        cfg.setProviderName("SunJCE");
        cfg.setSaltGenerator(getSalt());
//        cfg.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        cfg.setStringOutputType("base64");
        encryptor.setConfig(cfg);
        return encryptor;
    }

    private StringFixedSaltGenerator getSalt() {
        String salt = (String) ctx.getBean("salt");
        ConfigService cs = (ConfigService) ctx.getBean("configService");
        cs.loadConfig();
        if (cs.isConfigValid()) {
            salt = cs.getConfig().getSalt();
        }
        return new StringFixedSaltGenerator(salt, "UTF-8");
    }
}