package com.sportmaster.eafileserver.config_init;

import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.OperationTypeEnum;
import com.sportmaster.eafileserver.model.exception.ConfigException;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.service.ConfigService;
import com.sportmaster.eafileserver.service.LoggerService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Path;

import static com.sportmaster.eafileserver.utils.EafsUtils.defServerName;
import static java.nio.file.Files.*;

@Component
@AllArgsConstructor
@Slf4j
public class Init {
    private PropConfig propConfig;
    private LoggerService lg;
    private ConfigService configService;
    private ConfigFile defaultConfigFile;

    @PostConstruct
    private void init() {
        log.info("Server props: " + propConfig.toString());
        createSourceDirIfNeeded();
        createConfigDirIfNeeded();
        loadOrCreateBaseConfigFile();
        if (!initResultSuccess()) {
            log.error("Init fail");
        } else {
            log.info("Init complete OK");
            lg.success(OperationTypeEnum.ADMIN_REQUEST, new Token());
        }
    }

    private boolean initResultSuccess() {
        boolean result = true;
        Path sourceDir = propConfig.getSourceDir();
        if (!exists(sourceDir)) {
            log.error("Source directory '" + sourceDir.toString() + "' is absent ");
            result = false;
        }
        Path configDir = propConfig.getSysDir();
        if (!exists(configDir)) {
            log.error("Config directory '" + configDir.toString() + "' is absent ");
            result = false;
        }
        Path sysConfFile = propConfig.getSysConfFile();
        if (!exists(sysConfFile)) {
            log.error("Config config file '" + sysConfFile.toString() + "' is absent ");
            result = false;
        }
        return result;
    }

    private void loadOrCreateBaseConfigFile() {
        if (!exists(propConfig.getSysConfFile())) {
            try {
                createFile(propConfig.getSysConfFile());
            } catch (IOException e) {
                lg.error("Could not able to create config file", new Token());
                throw new ConfigException("Could not create config file");
            }
        }
        configService.loadConfig();
        fixConfigInit();
    }

    private void fixConfigInit() {
        ConfigFile config = configService.getConfig();
        if (config == null
                || config.getServername() == null
                    || "EUA1".toLowerCase().equals(config.getServername().toLowerCase())
                        || defServerName.toLowerCase().equals(config.getServername().toLowerCase())) {
            configService.saveConfig(defaultConfigFile);
            configService.loadConfig();
        }
    }

    private void createSourceDirIfNeeded() {
        Path dir = propConfig.getSourceDir();
        try {
            if (!exists(dir)) {
                try {
                    createDirectory(dir);
                } catch (IOException e) {
                    lg.error("Could not create source dir: " + dir.toString(), new Token());
                    throw new FileStorageException("Could not create source dir: " + dir.toString());
                }
            }
        } catch (Throwable e) {
            lg.error("Could not create source dir: " + dir.toString(), new Token());
            throw new FileStorageException("Could not create source dir: " + dir.toString());
        }
    }

    private void createConfigDirIfNeeded() {
        if (!exists(propConfig.getSysDir())) {
            try {
                createDirectory(propConfig.getSysDir());
            } catch (IOException e) {
                lg.error("Could not create config dir", new Token());
                throw new ConfigException("Could not create config dir");
            }
        }
    }
}
