package com.sportmaster.eafileserver.model.mapper;

import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.model.exception.ConfigException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Map;

import static com.sportmaster.eafileserver.utils.EafsUtils.dateTimeFormatter;
import static com.sportmaster.eafileserver.utils.EafsUtils.notNullOrEmpty;

@AllArgsConstructor
@Component
public class LoggerMapper {

    public String toUrlParam(LoggerDto dto) {
        String url = "";

        if (notNullOrEmpty(dto.getOperation())) {
            url += ("&operation=" + dto.getOperation());
        }
        if (notNullOrEmpty(dto.getStatus())) {
            url += ("&status=" + dto.getStatus());
        }
        if (notNullOrEmpty(dto.getUsername())) {
            url += ("&username=" + dto.getUsername());
        }
        if (notNullOrEmpty(dto.getFromServer())) {
            url += ("&fromServer=" + dto.getFromServer());
        }
        if (notNullOrEmpty(dto.getFileName())) {
            url += ("&fileName=" + dto.getFileName());
        }
        if (notNullOrEmpty(dto.getFileId())) {
            url += ("&fileId=" + dto.getFileId());
        }
        if (notNullOrEmpty(dto.getMsg())) {
            url += ("&msg=" + dto.getMsg());
        }
        if (dto.getDateFrom() != null) {
            url += ("&dateFrom=" + dto.getDateFrom().format(dateTimeFormatter));
        }
        if (dto.getDateTo() != null) {
            url += ("&dateTo=" + dto.getDateTo().format(dateTimeFormatter));
        }
        return url;
    }

    public LoggerDto toLoggerDto(Map<String, String[]> params) {
        LoggerDto dto = new LoggerDto();
        if (params == null || params.isEmpty()) {
            return dto;
        }
        params.forEach((k, v) -> {
            if (k.toLowerCase().equals("operation")) {
                dto.setOperation(v[0]);
            } else if (k.toLowerCase().equals("status")) {
                dto.setStatus(v[0]);
            } else if (k.toLowerCase().equals("username")) {
                dto.setUsername(v[0]);
            } else if (k.toLowerCase().equals("serverFrom".toLowerCase())) {
                dto.setFromServer(v[0]);
            } else if (k.toLowerCase().equals("fileName".toLowerCase())) {
                dto.setFileName(v[0]);
            } else if (k.toLowerCase().equals("fileId".toLowerCase())) {
                dto.setFileId(v[0]);
            } else if (k.toLowerCase().equals("dateFrom".toLowerCase())) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(v[0], dateTimeFormatter);
                    dto.setDateFrom(dateTime);
                } catch (DateTimeParseException e) {
                    throw new ConfigException(e.getMessage());
                }
            } else if (k.toLowerCase().equals("dateTo".toLowerCase())) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(v[0], dateTimeFormatter);
                    dto.setDateTo(dateTime);
                } catch (DateTimeParseException e) {
                    throw new ConfigException(e.getMessage());
                }
            } else if (k.toLowerCase().equals("msg")) {
                dto.setMsg(v[0]);
            }
        });
        return dto;
    }
}
