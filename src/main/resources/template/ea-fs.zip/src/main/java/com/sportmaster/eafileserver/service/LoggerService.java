package com.sportmaster.eafileserver.service;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.model.entity.LoggerEntity;
import com.sportmaster.eafileserver.model.enums.OperStatusEnum;
import com.sportmaster.eafileserver.model.enums.OperationTypeEnum;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.repo.LoggerRepository;
import lombok.AllArgsConstructor;
import org.hibernate.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;

@Service
@AllArgsConstructor
public class LoggerService {
    private LoggerRepository repo;
    private EntityManager em;

    @Transactional(readOnly = true)
    public LoggerEntity getById(long id) {
        Optional<LoggerEntity> one = repo.findById(id);
        return one.orElse(null);
    }

    @Transactional(readOnly = true)
    public List<LoggerEntity> findAllByExample(LoggerDto req) {
        if (req == null) {
            return Collections.emptyList();
        }

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<LoggerEntity> cq = cb.createQuery(LoggerEntity.class);
        Root<LoggerEntity> logEntity = cq.from(LoggerEntity.class);

        List<Predicate> predicates = new ArrayList<>();

        if (req.getDateTo() != null) {
            predicates.add(cb.lessThanOrEqualTo(logEntity.get("timestamp"), req.getDateTo()));
        }

        if (req.getDateFrom() != null) {
            predicates.add(cb.greaterThanOrEqualTo(logEntity.get("timestamp"), req.getDateFrom()));
        }

        if (req.getUsername() != null && !req.getUsername().isEmpty()) {
            predicates.add(cb.like(logEntity.get("username"), "%" + req.getUsername() + "%"));
        }

        if (req.getOperation() != null && !req.getOperation().isEmpty()) {
            Optional<OperationTypeEnum> result = Arrays.stream(OperationTypeEnum.values())
                    .filter(s -> s.toString().toLowerCase().equals(req.getOperation().toLowerCase()))
                    .findFirst();
            result.ifPresent(operationTypeEnum -> predicates.add(cb.equal(logEntity.get("operation"), operationTypeEnum)));
        }

        if (req.getStatus() != null && !req.getStatus().isEmpty()) {
            Optional<OperStatusEnum> result = Arrays.stream(OperStatusEnum.values())
                    .filter(s -> s.toString().toLowerCase().equals(req.getStatus().toLowerCase()))
                    .findFirst();
            result.ifPresent(operStatusEnum -> predicates.add(cb.equal(logEntity.get("status"), operStatusEnum)));
        }

        if (req.getFromServer() != null && !req.getFromServer().isEmpty()) {
            predicates.add(cb.like(logEntity.get("serverFrom"), "%" + req.getFromServer() + "%"));
        }

        if (req.getFileName() != null && !req.getFileName().isEmpty()) {
            predicates.add(cb.like(logEntity.get("fileName"), "%" + req.getFileName() + "%"));
        }

        if (req.getFileId() != null && !req.getFileId().isEmpty()) {
            predicates.add(cb.like(logEntity.get("fileId"), "%" + req.getFileId() + "%"));
        }

        if (req.getMsg() != null && !req.getMsg().isEmpty()) {
            predicates.add(cb.like(logEntity.get("msg"), "%" + req.getMsg() + "%"));
        }
        cq.where(predicates.toArray(new Predicate[0]));
        return em.createQuery(cq).getResultList();
    }

    @Transactional(readOnly = true)
    public List<LoggerEntity> findAll() {
        return repo.findAll();
    }

    @Transactional
    void addLogRecord(LoggerEntity entity) {
        if (entity != null) {
            String msg = entity.getMsg();
            if (notNullOrEmpty(msg) && msg.length() > 500) {
                entity.setMsg(entity.getMsg().substring(0, msgLength - 1));
            }
            repo.saveAndFlush(entity);
        }
    }

    @Transactional(readOnly = true)
    public List<LoggerEntity> findBySqlString(String query) {
        if (nullOrEmpty(query)) {
            return Collections.emptyList();
        }
        Session session = em.unwrap(Session.class);
        final List<LoggerEntity> entities = new ArrayList<>();
        session.doWork(con -> {
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    LoggerEntity en = new LoggerEntity();
                    try {
                        en.setId(rs.getLong("id"));
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setOperation(OperationTypeEnum.forValue(rs.getString("operation")));
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setStatus(OperStatusEnum.forValue(rs.getString("status")));
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setUsername(rs.getString("username"));
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setServerFrom(rs.getString("serverFrom"));
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setFileName(rs.getString("fileName"));
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setFileId(rs.getString("fileId"));
                    } catch (SQLException ignored) {
                    }
                    try {
                        if (rs.getTimestamp("timestamp") != null) {
                            en.setTimestamp(rs.getTimestamp("timestamp").toLocalDateTime());
                        }
                    } catch (SQLException ignored) {
                    }
                    try {
                        en.setFileId(rs.getString("msg"));
                    } catch (SQLException ignored) {
                    }
                    entities.add(en);
                }
            }
        });
        return entities;
    }

    public void error(OperationTypeEnum oper, String errMsg, Token token) {
        LoggerEntity en = new LoggerEntity(token);
        en.setStatus(OperStatusEnum.ERROR);
        en.setOperation(oper);
        en.setMsg(errMsg);
        addLogRecord(en);
    }

    public void deepLog(String msg) {
        LoggerEntity en = new LoggerEntity();
        en.setStatus(OperStatusEnum.SUCCESS);
        en.setOperation(OperationTypeEnum.DEEP_LOG);
        en.setMsg(msg);
        addLogRecord(en);
    }

    public void info(String msg) {
        LoggerEntity en = new LoggerEntity();
        en.setStatus(OperStatusEnum.SUCCESS);
        en.setOperation(OperationTypeEnum.DEEP_LOG);
        en.setMsg(msg);
        addLogRecord(en);
    }

    public void error(String errMsg, Token token) {
        LoggerEntity en = new LoggerEntity(token);
        en.setStatus(OperStatusEnum.ERROR);
        en.setMsg(errMsg);
        addLogRecord(en);
    }

    public void success(OperationTypeEnum oper, Token token) {
        LoggerEntity en = new LoggerEntity(token);
        en.setStatus(OperStatusEnum.SUCCESS);
        en.setOperation(oper);
        addLogRecord(en);
    }

    public void success(OperationTypeEnum oper, Object obj, Token token) {
        LoggerEntity en = new LoggerEntity(token, obj);
        en.setStatus(OperStatusEnum.SUCCESS);
        en.setOperation(oper);
        addLogRecord(en);
    }
}
