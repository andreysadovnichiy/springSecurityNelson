package com.sportmaster.eafileserver.model.exception;

public class ConfigException extends RuntimeException {
    public ConfigException(String message) {
        super(message);
    }
}
