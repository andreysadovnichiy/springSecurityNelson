package com.sportmaster.eafileserver.model.exception;

public class TokenException extends RuntimeException {
    public TokenException(String message) {
        super(message);
    }
}
