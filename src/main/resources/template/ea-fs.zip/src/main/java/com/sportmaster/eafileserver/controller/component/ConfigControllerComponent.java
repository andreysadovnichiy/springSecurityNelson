package com.sportmaster.eafileserver.controller.component;

import com.sportmaster.eafileserver.service.EncryptorResolverService;
import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.service.ConfigService;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import static com.sportmaster.eafileserver.model.enums.OperationTypeEnum.ADMIN_REQUEST;
import static java.util.stream.Collectors.joining;
import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.HttpStatus.*;

@Component
@AllArgsConstructor
public class ConfigControllerComponent {
    private final ConfigService configService;
    private final JsonMapperService mapper;
    private final LoggerService log;
    private final RequestScopeHolder tokenHolder;
    private final EncryptorResolverService encryptorResolverService;

    public ResponseEntity<String> restart() {
        log.success(ADMIN_REQUEST, tokenHolder.getToken());
//        EaFileServerApplication.restart();
        return new ResponseEntity<>(OK);
    }

    public ResponseEntity<String> getConfig() {
        String json = mapper.encodePrettyPrint(configService.getConfig());
        log.success(ADMIN_REQUEST, tokenHolder.getToken());
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/octet-stream"))
                .header(CONTENT_DISPOSITION, "attachment; filename=\"" + "config" + "\"")
                .body(json);
    }

    public ResponseEntity<String> postConfig(MultipartFile file) throws IOException {
        InputStream is = file.getInputStream();
        String json = new BufferedReader(new InputStreamReader(is)).lines().collect(joining("\n"));

        ConfigFile cf = (ConfigFile) mapper.decode(json, ConfigFile.class);
        boolean isValid = configService.validateConfig(cf);
        if (isValid) {
            configService.saveConfig(cf);
            encryptorResolverService.refresh();
            log.success(ADMIN_REQUEST, cf, tokenHolder.getToken());
            return new ResponseEntity<>(CREATED);
        } else {
            log.error("Illegal file configuration!", tokenHolder.getToken());
            return new ResponseEntity<>("Illegal action type", CONFLICT);
        }
    }
}
