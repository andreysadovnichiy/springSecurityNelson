package com.sportmaster.eafileserver.model.dto.response;

import com.sportmaster.eafileserver.model.Token;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ParseParamRespDto {
    private Token token;
}
