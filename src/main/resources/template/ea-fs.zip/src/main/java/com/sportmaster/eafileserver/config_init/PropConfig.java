package com.sportmaster.eafileserver.config_init;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ConfigurationProperties("application.properties")
public class PropConfig {
    @Value("${config.file-upload-dir}")
    private String uploadDir;

    @Value("${config.config-dir}")
    private String configDir;

    @Value("${config.nlayer.dir.enable}")
    private boolean nlayerDir;

    @Value("${config.nlayer.targetdir.capacity}")
    private int nlayerTargetDirCapacity;

    @Value("${config.file}")
    private String configFile;

    @Value("#{'${config.servers}'.split(';')}")
    private List<String> srvrs;

    public int getNlayerTargetDirCapacity() {
        return nlayerTargetDirCapacity;
    }

    public boolean isNlayerDir() {
        return nlayerDir;
    }

    public String getUploadDir() {
        return uploadDir;
    }

    Path getSysDir() {
        return Paths.get(configDir).toAbsolutePath().normalize();
    }

    Path getSourceDir() {
        return Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    public Path getSysConfFile() {
        return Paths.get(configDir + "/" + configFile).toAbsolutePath().normalize();
    }

    public Map<String, String> getServersToFind() {
        Map<String, String> servers = new HashMap<>();
        this.srvrs.forEach(s -> {
            String res = s.trim();
            int i = res.indexOf("=");
            servers.put(res.substring(0, i).trim().toLowerCase(), res.substring(i + 1).trim().toLowerCase());
        });
        return servers;
    }

    @Override
    public String toString() {
        return "PropConfig{" +
                "uploadDir='" + uploadDir + '\'' +
                ", configDir='" + configDir + '\'' +
                ", configFile='" + configFile + '\'' +
                ", srvrs=" + srvrs +
                '}';
    }
}
