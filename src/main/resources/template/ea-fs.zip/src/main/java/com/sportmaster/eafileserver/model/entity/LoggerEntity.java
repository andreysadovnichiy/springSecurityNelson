package com.sportmaster.eafileserver.model.entity;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.OperStatusEnum;
import com.sportmaster.eafileserver.model.enums.OperationTypeEnum;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;

@Data
@Entity(name = "eafslogger")
@NoArgsConstructor
public class LoggerEntity {
    @Id
    @GeneratedValue
    private Long id;

    @Column(length = operationnameLength)
    @Enumerated(EnumType.STRING)
    private OperationTypeEnum operation;

    @Column(length = statusLength)
    @Enumerated(EnumType.STRING)
    private OperStatusEnum status;

    @Column(length = usernameLength)
    private String username;

    @Column(name = "serverfrom", length = serverfromLength)
    private String serverFrom;

    @Column(name = "filename", length = filenameLength)
    private String fileName;

    @Column(name = "fileid", length = fileidLength)
    private String fileId;

    private LocalDateTime timestamp;

    @Column(length = msgLength)
    private String msg;

    public LoggerEntity(Token token) {
        if (token != null) {
            this.serverFrom = token.getFromServer();
            this.fileName = token.getFullName();
            this.fileId = token.getFileId();
            this.username = token.getUsername();
            if (token.getActionType() != null) {
                this.msg = token.getActionType().toString();
            }
        }
        this.timestamp = nowGreenwichDateTimeWithoutMills();
    }

    public LoggerEntity(Token token, Object obj) {
        this(token);
        if (token != null && obj != null) {
            this.msg = token.getActionType().toString() + ": " + obj.toString();
        }
    }
}
