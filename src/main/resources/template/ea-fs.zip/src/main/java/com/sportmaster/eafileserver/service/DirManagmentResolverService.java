package com.sportmaster.eafileserver.service;

import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.utils.EafsUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.sportmaster.eafileserver.utils.EafsUtils.nLayerAdd;

@Service
@AllArgsConstructor
public class DirManagmentResolverService {
    private PropConfig propConfig;
    private NlayerDirectoryManagementService nlayerDirectoryManagementService;
    private LoggerService log;

    Path createTargetDir(Token token) {
        String param;
        String fileId = token.getFromServer() + "-" + new Date().getTime();
        Path path = null;
        try {
            if (propConfig.isNlayerDir()) {
                param = nlayerDirectoryManagementService.createStructureAndGetParam();
                String targetDir = nlayerDirectoryManagementService.getTargetDir(param);
                path = Paths.get(targetDir + "/" + fileId).toAbsolutePath().normalize();
                fileId = nLayerAdd(fileId, param);
            } else {
                path = Paths.get(propConfig.getUploadDir() + "/" + fileId).toAbsolutePath().normalize();
            }
            Files.createDirectory(path);
            token.setFileId(fileId);
            return path;
        } catch (IOException e) {
            log.error(e.getMessage(), token);
            throw new FileStorageException("File saving error by id: " + fileId + " or creating directory error: " + path);
        }
    }

    public static List<String> rootDirFileList(String root) {
        List<String> result = Collections.emptyList();
        try (Stream<Path> walk = Files.walk(Paths.get(root))) {
            result = walk.filter(Files::isRegularFile).map(Path::toString).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
}
