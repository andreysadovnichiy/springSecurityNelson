package com.sportmaster.eafileserver.model;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.sportmaster.eafileserver.model.enums.OsEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@JsonPropertyOrder({ "servername",
        "emailOfAdmin",
        "salt",
        "partitions",
        "os",
        "restartDate",
        "restartForce"})
public class ConfigFile {
    private String servername;
    private String emailOfAdmin;
    private String salt;
    private List<Partition> partitions;
    private OsEnum os;
    private Date restartDate;
    private Boolean restartForce;
}
