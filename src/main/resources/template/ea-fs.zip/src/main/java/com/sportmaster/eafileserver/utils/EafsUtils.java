package com.sportmaster.eafileserver.utils;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.exception.TokenException;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static java.time.LocalDateTime.now;
import static java.time.ZoneId.of;
import static java.util.Arrays.asList;

public class EafsUtils {

    public static final String defServerName = "def-name";

    public static final String propWeblogicName = "weblogic.Name";

    public static final int filenameLength = 255;

    public static final int usernameLength = 50;

    public static final int operationnameLength = 15;

    public static final int statusLength = 10;

    public static final int serverfromLength = 50;

    public static final int fileidLength = 100;

    public static final int msgLength = 500;

    public static boolean isAbc(String s) {
        return s != null && s.matches("^[a-zA-Z]*$");
    }

    public static String nLayerGetParam(String s) {
        //ea-file-server-ZYSEFK-1583413242877
        if (s.length() < 20) {
            return "";
        }
        return s.substring(s.length() - 20, s.length() - 14);
    }

    public static String nLayerGetFolder(String s) {
        String param = nLayerGetParam(s) + "-";
        return s.replace(param, "");
    }

    public static String nLayerAdd(String s, String param) {
        String suff = s.substring(s.length() - 14, s.length());
        return s.replace(suff, "") + "-" + param + suff;
    }

    public static boolean isNlayer(String s) {
        String param = nLayerGetParam(s);
        if (nullOrEmpty(param)) {
            return false;
        }
        return s.contains("-" + param.toUpperCase() + "-");
    }

    public static boolean isNlayerParamValid(String s) {
        return s != null && s.length() == 6 && s.matches("^[a-zA-Z]*$");
    }

    public static List<File> getFilesInDir(String path) {
        List<File> result = new ArrayList<>();
        File[] files = new File(path).listFiles();
        if (files == null) {
            return result;
        }
        return asList(files);
    }

    public static LocalDateTime nowDateTimeWithoutMills() {
        return now().withNano(0);
    }

    public static LocalDateTime nowGreenwichDateTimeWithoutMills() {
        return now(of("Europe/London")).withNano(0);
    }

    public static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    public static boolean nullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }

    public static boolean notNullOrEmpty(String s) {
        return !(s == null || s.isEmpty());
    }

    public static boolean nullOrEmpty(Collection s) {
        return s == null || s.isEmpty();
    }

    public static boolean notNullOrEmpty(Collection s) {
        return !nullOrEmpty(s);
    }

    public static void validateTokenFieldsNotNullOrEmpty(Token token, List<String> vars) {
        if (vars.contains("username") && nullOrEmpty(token.getUsername())) {
            throw new TokenException("Username field expected");
        }
        if (vars.contains("fromServer") && nullOrEmpty(token.getFromServer())) {
            throw new TokenException("FromServer field expected");
        }
        if (vars.contains("fileId") && nullOrEmpty(token.getFileId())) {
            throw new TokenException("FileId field expected");
        }
        if (vars.contains("fullName")) {
            if (nullOrEmpty(token.getFullName())) {
                throw new TokenException("FullName field expected");
            }
            if (token.getFullName().length() > filenameLength) {
                throw new TokenException("FullName field length must be less then " + filenameLength);
            }
        }
        if (vars.contains("actionType") && token.getActionType() == null) {
            throw new TokenException("ActionType field expected");
        }
        if (vars.contains("dateFrom") && token.getDateFrom() == null) {
            throw new TokenException("DateFrom field expected");
        }
        if (vars.contains("dateTo") && token.getDateTo() == null) {
            throw new TokenException("DateTo field expected");
        }
        if (vars.contains("hddType") && token.getHddType() == null) {
            throw new TokenException("HddType field expected");
        }
    }
}
