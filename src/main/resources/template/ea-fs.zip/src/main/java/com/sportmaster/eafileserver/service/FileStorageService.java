package com.sportmaster.eafileserver.service;

import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.utils.EafsUtils;
import lombok.AllArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static com.sportmaster.eafileserver.utils.EafsUtils.*;

@Service
@AllArgsConstructor
public class FileStorageService {
    private PropConfig propConfig;
    private DirManagmentResolverService dirService;
    private NlayerDirectoryManagementService nlayerDirectoryManagementService;

    @PostConstruct
    private void init() {
        Path root = Paths.get(propConfig.getUploadDir()).toAbsolutePath().normalize();
        if (!Files.exists(root)) {
            throw new FileStorageException("Could not access root storage directory");
        }
    }

    private void validateFilename(String fileName) {
        boolean isValid = true;
        if (fileName.contains("..")) {
            isValid = false;
        }
        if (!isValid) {
            throw new FileStorageException("Filename contains invalid path sequence " + fileName);
        }
    }

    public void saveResourceToStorage(MultipartFile file, Token token) {
        validateFilename(token.getFullName());
        try {
            Path target = dirService.createTargetDir(token);
            Files.copy(file.getInputStream(), target.resolve(token.getFullName()), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            throw new FileStorageException("Could not save file " + token.getFullName());
        }
    }

    public void saveResourceToStorage(String fileBody, Token token) {
        byte[] bytes = Base64.getDecoder().decode(fileBody);
        validateFilename(token.getFullName());
        try {
            Path target = dirService.createTargetDir(token);
            Files.copy(new ByteArrayInputStream(bytes), target.resolve(token.getFullName()), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            throw new FileStorageException("Could not save file " + token.getFullName());
        }
    }

    private Path resolveResourcePath(@NotNull Token token) {
        String fileId = token.getFileId();
        String path;
        if (isNlayer(fileId)) {
            String param = nLayerGetParam(fileId);
            String folder = nLayerGetFolder(fileId);
            path = nlayerDirectoryManagementService.getTargetDir(param) + "/" + folder + "/" + token.getFullName();
        } else {
            String dirName = propConfig.getUploadDir() + "/" + token.getFileId() + "/";
            path = dirName + token.getFullName();
        }
        return Paths.get(path).toAbsolutePath().normalize();
    }

    public Resource findResourceInStorage(Token token) {
        String errMsg = "Could not find file by id: " + token.getFileId();
        Path path = resolveResourcePath(token);
        if (!Files.exists(path)) {
            throw new FileStorageException(errMsg + " on path: " + path.toString());
        }
        try {
            Resource resource = new UrlResource(path.toUri());
            if (resource.exists()) {
                return resource;
            } else {
                throw new FileStorageException(errMsg + " Resource doesn`t exists");
            }
        } catch (MalformedURLException e) {
            throw new FileStorageException(errMsg);
        }
    }

    public StreamingResponseBody findResourceAndStreamingInStorage(Token token, final HttpServletResponse response) {
        String errMsg = "Could not find file by id: " + token.getFileId();
        Path path = resolveResourcePath(token);
        if (!Files.exists(path)) {
            throw new FileStorageException(errMsg + " on path: " + path.toString());
        }
        StreamingResponseBody stream1 = outputStream -> {
            final File file = path.toFile();
            final ZipOutputStream zipOut = new ZipOutputStream(response.getOutputStream());
            try {
                final InputStream inputStream = new FileInputStream(file);
                final ZipEntry zipEntry = new ZipEntry(file.getName());
                zipOut.putNextEntry(zipEntry);
                byte[] bytes = new byte[1024];
                int length;
                while ((length = inputStream.read(bytes)) >= 0) {
                    zipOut.write(bytes, 0, length);
                }
                inputStream.close();
                zipOut.close();
            } catch (final IOException e) {
                throw new FileStorageException("Exception while reading and streaming data: " + e.getMessage());
            }
        };
        StreamingResponseBody stream = out -> {
            final File file = path.toFile();
            final ZipOutputStream zipOut = new ZipOutputStream(response.getOutputStream());
            try {
                final InputStream inputStream = new FileInputStream(file);
                final ZipEntry zipEntry = new ZipEntry(file.getName());
                zipOut.putNextEntry(zipEntry);
                byte[] bytes = new byte[1024];
                int length;
                while ((length = inputStream.read(bytes)) >= 0) {
                    zipOut.write(bytes, 0, length);
                }
                inputStream.close();
                zipOut.close();
            } catch (final IOException e) {
                throw new FileStorageException("Exception while reading and streaming data: " + e.getMessage());
            }
        };
        return stream1;
    }
}