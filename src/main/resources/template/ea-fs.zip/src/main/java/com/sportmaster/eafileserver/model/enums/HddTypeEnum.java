package com.sportmaster.eafileserver.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

public enum HddTypeEnum {
    TYPE_1,
    TYPE_2;

    private static Map<String, HddTypeEnum> namesEnum = new HashMap<>();

    static {
        namesEnum.put("TYPE_1", HddTypeEnum.TYPE_1);
        namesEnum.put("TYPE_2", HddTypeEnum.TYPE_2);
    }

    @JsonCreator
    public static HddTypeEnum forValue(String value) {
        if(value == null || value.isEmpty()) {
            return null;
        }
        return namesEnum.get(value.toUpperCase());
    }

    @JsonValue
    public String toValue() {
        return this.toString();
    }

}
