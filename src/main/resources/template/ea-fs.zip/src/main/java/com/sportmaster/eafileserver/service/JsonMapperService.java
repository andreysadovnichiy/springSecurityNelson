package com.sportmaster.eafileserver.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class JsonMapperService {
    private ObjectMapper mapper;

    public String encode(Object obj) {
        String json = null;
        try {
            json = mapper.writeValueAsString(obj);
        } catch (Exception ignored) {
        }
        return json;
    }

    public String encodePrettyPrint(Object obj) {
        String json = null;
        try {
            json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
        } catch (Exception ignored) {
        }
        return json;
    }

    public Object decode(String json, Class clazz) {
        Object obj = null;
        try {
            obj = mapper.readValue(json, clazz);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return obj;
    }
}
