package com.sportmaster.eafileserver.controller;

import com.sportmaster.eafileserver.config_init.PropConfig;
import com.sportmaster.eafileserver.model.dto.*;
import com.sportmaster.eafileserver.model.dto.request.GenerateReqDto;
import com.sportmaster.eafileserver.model.dto.request.ParseParamReqDto;
import com.sportmaster.eafileserver.model.dto.response.GenerateRespDto;
import com.sportmaster.eafileserver.model.dto.response.ParseParamRespDto;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.model.exception.TokenException;
import com.sportmaster.eafileserver.service.DirManagmentResolverService;
import com.sportmaster.eafileserver.service.JsonMapperService;
import com.sportmaster.eafileserver.service.SecurityService;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sportmaster.eafileserver.utils.EafsUtils.dateTimeFormatter;
import static com.sportmaster.eafileserver.utils.EafsUtils.notNullOrEmpty;
import static com.sportmaster.eafileserver.utils.ServletUtils.*;
import static java.lang.String.join;
import static org.springframework.http.HttpStatus.OK;

@Controller
@AllArgsConstructor
public class GenerateParamController {
    private final SecurityService securityService;
    private final JsonMapperService mapper;
    private PropConfig propConfig;

    @GetMapping(GENERATE_GET_PATH)
    public ResponseEntity<Object> generateGetPath() {
        return new ResponseEntity<>(propConfig.toString(), OK);
    }

    @GetMapping(GENERATE_DIR_LIST)
    public ResponseEntity<Object> generateDirList(String query) {
        List<String> files = DirManagmentResolverService.rootDirFileList(propConfig.getUploadDir());
        return new ResponseEntity<>(files, OK);
    }

    @PostMapping(PARSE_PARAM)
    public ResponseEntity<ParseParamRespDto> parseParam(@RequestBody String json) {
        ParseParamReqDto req = (ParseParamReqDto) mapper.decode(json, ParseParamReqDto.class);
        if (req == null) {
            return ResponseEntity.badRequest().build();
        }
        String decrypted = securityService.decrypt(req.getParam(), false);
        if (decrypted == null) {
            throw new TokenException("Bad token decryption!");
        }

        Token token = securityService.parseParams(decrypted);
        if (token == null) {
            throw new TokenException("Broken token!");
        }

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .body(new ParseParamRespDto(token));
    }

    @PostMapping(GENERATE)
    public ResponseEntity<GenerateRespDto> generateParam1(@RequestBody String json) {
        GenerateReqDto req = (GenerateReqDto) mapper.decode(json, GenerateReqDto.class);
        if (req == null) {
            return ResponseEntity.badRequest().build();
        }

        Token token = req.getToken();
        String encrypt = securityService.encryptObject(token);
        String url = req.getHost() + ENTRY_POINT + "?param=" + encrypt;

        if (token.getActionType() == ActionTypeEnum.LOG) {
            LoggerDto loggerDto = req.getLogRequest();
            Map<String, String> map = loggerRequestToMap(loggerDto);
            url = url + addLoggerRequestParams(map);
        }

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .body(new GenerateRespDto(url, encrypt));
    }

    @GetMapping(GENERATE_PARAM)
    public ResponseEntity<String> generateParam(@RequestParam("token") String tokenJson,
                                                @RequestParam(value = "logRequest", required = false) String loggerRequestJson) {

        Token token = (Token) mapper.decode(tokenJson, Token.class);
        String encrypt = securityService.encrypt(tokenJson);
        String url = ENTRY_POINT + "?param=" + encrypt;

        if (token.getActionType() == ActionTypeEnum.LOG) {
            if (loggerRequestJson != null) {
                LoggerDto loggerDto = (LoggerDto) mapper.decode(tokenJson, LoggerDto.class);
                Map<String, String> map = loggerRequestToMap(loggerDto);
                url = url + addLoggerRequestParams(map);
            }
        }

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .body(url);
    }

    private String addLoggerRequestParams(Map<String, String> map) {
        List<String> pairs = new ArrayList<>();
        map.forEach((k, v) -> pairs.add("&" + k + "=" + v));
        return join("", pairs);
    }

    private Map<String, String> loggerRequestToMap(LoggerDto in) {
        Map<String, String> map = new HashMap<>();
        if (notNullOrEmpty(in.getOperation())) {
            map.put("operation", in.getOperation());
        }
        if (notNullOrEmpty(in.getStatus())) {
            map.put("status", in.getStatus());
        }
        if (notNullOrEmpty(in.getUsername())) {
            map.put("username", in.getUsername());
        }
        if (notNullOrEmpty(in.getFromServer())) {
            map.put("serverFrom", in.getFromServer());
        }
        if (notNullOrEmpty(in.getFileId())) {
            map.put("fileName", in.getFileId());
        }
        if (notNullOrEmpty(in.getMsg())) {
            map.put("msg", in.getMsg());
        }
        if (in.getDateFrom() != null) {
            map.put("dateFrom", in.getDateFrom().format(dateTimeFormatter));
        }
        if (in.getDateTo() != null) {
            map.put("dateTo", in.getDateTo().format(dateTimeFormatter));
        }
        return map;
    }

    @GetMapping(GENERATE)
    public String page() {
        return "generator";
    }
}
