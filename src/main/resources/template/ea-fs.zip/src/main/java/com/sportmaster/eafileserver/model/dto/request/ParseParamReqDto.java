package com.sportmaster.eafileserver.model.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.boot.jackson.JsonComponent;

@Data
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParseParamReqDto {
    private String param;
}
