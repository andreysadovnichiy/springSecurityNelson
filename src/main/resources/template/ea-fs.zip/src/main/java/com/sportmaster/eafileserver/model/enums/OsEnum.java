package com.sportmaster.eafileserver.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

public enum OsEnum {
    WINDOWS,
    LINUX;

    private static Map<String, OsEnum> namesEnum = new HashMap<>();

    static {
        namesEnum.put("WINDOWS", OsEnum.WINDOWS);
        namesEnum.put("LINUX", OsEnum.LINUX);
    }

    @JsonCreator
    public static OsEnum forValue(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return namesEnum.get(value.toUpperCase());
    }

    @JsonValue
    public String toValue() {
        return this.toString();
    }
}
