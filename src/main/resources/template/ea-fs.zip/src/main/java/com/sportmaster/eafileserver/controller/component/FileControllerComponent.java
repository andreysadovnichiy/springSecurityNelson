package com.sportmaster.eafileserver.controller.component;

import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.response.FindFileRespDto;
import com.sportmaster.eafileserver.model.dto.response.UploadRespDto;
import com.sportmaster.eafileserver.service.*;
import lombok.AllArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static com.sportmaster.eafileserver.model.enums.OperationTypeEnum.DOWNLOAD;
import static com.sportmaster.eafileserver.model.enums.OperationTypeEnum.UPLOAD;
import static com.sportmaster.eafileserver.utils.EafsUtils.nullOrEmpty;
import static com.sportmaster.eafileserver.utils.ServletUtils.getContentDepositionByFilename;
import static com.sportmaster.eafileserver.utils.ServletUtils.getContentTypeByFilename;
import static java.net.URLDecoder.decode;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.util.Collections.singletonList;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.MediaType.parseMediaType;

@Component
@AllArgsConstructor
public class FileControllerComponent {
    private RequestScopeHolder tokenHolder;
    private FileStorageService fileStorageService;
    private FindFileService findFileService;
    private ConfigService configService;
    private ConfigService confService;
    private LoggerService log;

    public ResponseEntity <StreamingResponseBody> streamingDownload(final HttpServletResponse response, Token token) throws UnsupportedEncodingException {

        response.setContentType("application/zip");
        response.setHeader(
                "Content-Disposition",
                "attachment;filename=sample.zip");

        StreamingResponseBody stream = fileStorageService.findResourceAndStreamingInStorage(token, response);

        return new ResponseEntity(stream, OK);
    }

    public ResponseEntity<Resource> download() throws UnsupportedEncodingException {
        Resource resource = fileStorageService.findResourceInStorage(tokenHolder.getToken());
        String filename = resource.getFilename();
        assert filename != null;
        log.success(DOWNLOAD, tokenHolder.getToken());

        ContentDisposition contentDisposition = ContentDisposition.builder(getContentDepositionByFilename(filename))
                .filename(decode(filename, "UTF-8"), UTF_8)
                .build();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentDisposition(contentDisposition);

        return ResponseEntity.ok()
                .contentType(parseMediaType(getContentTypeByFilename(filename)))
                .headers(httpHeaders)
                .body(resource);
    }

    public ResponseEntity<?> upload(MultipartFile file) {
        Token token = tokenHolder.getToken();
        fileStorageService.saveResourceToStorage(file, token);
        log.success(UPLOAD, token);
        return new ResponseEntity<>(new UploadRespDto(token.getFileId(), confService.getConfig().getServername()), CREATED);
    }

    public ResponseEntity<?> upload(String fileBody) {
        Token token = tokenHolder.getToken();
        fileStorageService.saveResourceToStorage(fileBody, token);
        log.success(UPLOAD, token);
        return new ResponseEntity<>(new UploadRespDto(token.getFileId(), confService.getConfig().getServername()), CREATED);
    }

    public ResponseEntity<FindFileRespDto> findFileGlobal() {
        Token token = tokenHolder.getToken();
        String fileId = token.getFileId();
        String fullName = token.getFullName();
        List<String> urls = findFileService.findFileGlobal(fileId, fullName);
        if (urls.isEmpty()) {
            return new ResponseEntity<>(NOT_FOUND);
        } else {
            return new ResponseEntity<>(new FindFileRespDto(urls), OK);
        }
    }

    public ResponseEntity<?> findFileLocal() {
        Token token = tokenHolder.getToken();
        String fileId = token.getFileId();
        String fullName = token.getFullName();
        String serv = null;
        if (findFileService.isFileLocalExists(fileId, fullName)) {
            serv = configService.getConfig().getServername().trim().toLowerCase();
        }
        if (nullOrEmpty(serv)) {
            return new ResponseEntity<>(NOT_FOUND);
        } else {
            return new ResponseEntity<>(new FindFileRespDto(singletonList(serv)), OK);
        }
    }
}