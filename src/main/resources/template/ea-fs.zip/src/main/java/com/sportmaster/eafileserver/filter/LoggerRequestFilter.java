package com.sportmaster.eafileserver.filter;

import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.model.enums.ActionTypeEnum;
import com.sportmaster.eafileserver.model.mapper.LoggerMapper;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import lombok.AllArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@Component
@Order(5)
@AllArgsConstructor
public class LoggerRequestFilter extends OncePerRequestFilter {
    private RequestScopeHolder requestScopeHolder;
    private LoggerMapper loggerMapper;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        if (requestScopeHolder != null && requestScopeHolder.getToken() != null) {
            return requestScopeHolder.getToken().getActionType() != ActionTypeEnum.LOG;
        }
        return true;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws ServletException, IOException {
        Map<String, String[]> params = req.getParameterMap();
        LoggerDto loggerDto = loggerMapper.toLoggerDto(params);
        requestScopeHolder.setLoggerDto(loggerDto);
        chain.doFilter(req, resp);
    }
}
