package com.sportmaster.eafileserver.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

public enum ActionTypeEnum {
    UPLOAD,
    DOWNLOAD,
    CONFIG_GET,
    CONFIG_POST,
    CONFIG_PUT_RESTART,
    LOG,
    RESTART_SERVER,
    FIND_FILE_GLOBAL,
    FIND_FILE_LOCAL;

    private static Map<String, ActionTypeEnum> namesEnum = new HashMap<>();

    static {
        namesEnum.put("UPLOAD", ActionTypeEnum.UPLOAD);
        namesEnum.put("DOWNLOAD", ActionTypeEnum.DOWNLOAD);
        namesEnum.put("CONFIG_GET", ActionTypeEnum.CONFIG_GET);
        namesEnum.put("CONFIG_POST", ActionTypeEnum.CONFIG_POST);
        namesEnum.put("CONFIG_PUT_RESTART", ActionTypeEnum.CONFIG_PUT_RESTART);
        namesEnum.put("LOG", ActionTypeEnum.LOG);
        namesEnum.put("RESTART_SERVER", ActionTypeEnum.RESTART_SERVER);
        namesEnum.put("FIND_FILE_GLOBAL", ActionTypeEnum.FIND_FILE_GLOBAL);
        namesEnum.put("FIND_FILE_LOCAL", ActionTypeEnum.FIND_FILE_LOCAL);
    }

    @JsonCreator
    public static ActionTypeEnum forValue(String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return namesEnum.get(value.toUpperCase());
    }

    @JsonValue
    public String toValue() {
        return this.toString();
    }
}
