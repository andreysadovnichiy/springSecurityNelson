package com.sportmaster.eafileserver.service;

import com.sportmaster.eafileserver.model.dto.LoggerDto;
import com.sportmaster.eafileserver.model.Token;
import com.sportmaster.eafileserver.model.dto.request.FileAsJsonReqDto;
import lombok.Data;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
@Data
public class RequestScopeHolder {
    private Token token;
    private LoggerDto loggerDto;
    private FileAsJsonReqDto jsonBodyDto;
}
