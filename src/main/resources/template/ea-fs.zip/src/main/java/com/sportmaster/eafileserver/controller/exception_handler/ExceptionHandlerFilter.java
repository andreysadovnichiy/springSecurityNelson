package com.sportmaster.eafileserver.controller.exception_handler;

import com.sportmaster.eafileserver.model.exception.ConfigException;
import com.sportmaster.eafileserver.model.exception.FileStorageException;
import com.sportmaster.eafileserver.model.exception.TokenException;
import com.sportmaster.eafileserver.service.LoggerService;
import com.sportmaster.eafileserver.service.RequestScopeHolder;
import lombok.AllArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.sportmaster.eafileserver.utils.ServletUtils.notApplyFilterTo;
import static org.springframework.http.HttpStatus.*;

@Component
@Order(0)
@AllArgsConstructor
public class ExceptionHandlerFilter extends OncePerRequestFilter {
    private LoggerService log;
    private RequestScopeHolder tokenHolder;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        return notApplyFilterTo.stream()
                .anyMatch(s -> req.getServletPath().startsWith(s));
    }

    @Override
    public void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain filterChain) throws ServletException, IOException {
        try {
            filterChain.doFilter(req, resp);
        } catch (RuntimeException ex) {
            int httpStatus = INTERNAL_SERVER_ERROR.value();
            if (ex instanceof ConfigException) {
                httpStatus = CONFLICT.value();
            } else if (ex instanceof FileStorageException) {
                httpStatus = NOT_FOUND.value();
            } else if (ex instanceof TokenException) {
                httpStatus = FORBIDDEN.value();
            }
            log.error(ex.getMessage(), tokenHolder.getToken());
            resp.sendError(httpStatus, ex.getMessage());
        }
    }
}
