package com.sportmaster.eafileserver.config_init;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.sportmaster.eafileserver.model.ConfigFile;
import com.sportmaster.eafileserver.model.Partition;
import com.sportmaster.eafileserver.model.enums.OsEnum;
import com.sportmaster.eafileserver.utils.EafsUtils;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import javax.sql.DataSource;
import javax.validation.Validation;
import javax.validation.Validator;

import java.util.Arrays;

import static com.sportmaster.eafileserver.model.enums.OsEnum.LINUX;
import static com.sportmaster.eafileserver.utils.EafsUtils.*;


@Configuration
public class AppConfig {
    @Value("${config.salt}")
    private String salt;

    @Autowired
    private Environment env;

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public ObjectMapper mapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper;
    }

    @Bean
    public Validator validator() {
        return Validation.buildDefaultValidatorFactory().getValidator();
    }

    @Bean("salt")
    public String getSalt() {
        return salt;
    }

    @Bean
    public DataSource getDataSource() {
        String dbSuf = "/eafs";
        DataSourceBuilder builder = DataSourceBuilder.create();
        String url = env.getProperty("spring.datasource.url");
        String webLogicProp = System.getProperty("weblogic.Name");
        if (notNullOrEmpty(webLogicProp)) {
            String dbNewSuf = dbSuf.substring(0, dbSuf.length() - 1) + "__" + webLogicProp;
            url = url.replace(dbSuf, dbNewSuf);
        }
        builder.driverClassName(env.getProperty("spring.datasource.driver-class-name"));
        builder.username(env.getProperty("spring.datasource.username"));
        builder.password(env.getProperty("spring.datasource.password"));
        builder.type(HikariDataSource.class);
        builder.url(url);
        return builder.build();
    }

    @Bean
    public ConfigFile getConfigFile() {
        ConfigFile cf = new ConfigFile();
        cf.setServername(defServerName);
        String nameProp = System.getProperty(propWeblogicName);
        if (notNullOrEmpty(nameProp)) {
            cf.setServername(nameProp);
        }
        cf.setEmailOfAdmin("test@email.com");
        cf.setSalt("This is cool salt!");
        cf.setOs(LINUX);
        cf.setPartitions(Arrays.asList(new Partition("name1", "type1")));
        return cf;
    }
}
