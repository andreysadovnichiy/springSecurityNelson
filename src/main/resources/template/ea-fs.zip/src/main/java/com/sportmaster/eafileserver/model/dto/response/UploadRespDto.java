package com.sportmaster.eafileserver.model.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UploadRespDto {
    private String fileId;
    private String fromServer;
}
