package com.sportmaster.eafileserver.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sportmaster.eafileserver.properties.MultipartProperty;
import com.sportmaster.eafileserver.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLDecoder;
import java.util.*;

@RestController
@RequestMapping("api/v1")
public class MultipartRedirectController {
    private final Logger log = LoggerFactory.getLogger(MultipartRedirectController.class);

    @Autowired
    private MultipartProperty multipartProperty;

    @GetMapping("/server-url")
    public ResponseEntity<String> getServerUrl() {
        return new ResponseEntity<>(getJsonSchemaMap(), HttpStatus.OK);
    }

    private String getJsonSchemaMap() {
        String json = null;
        try {
            json = new ObjectMapper().writeValueAsString(multipartProperty.getSchemaMap());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }

    @GetMapping(value = {"/upload", "/files"})
    public void getUrl(HttpServletRequest request, HttpServletResponse response) {
        try {
            String schema = request.getParameter("schema");
            String schema1 = multipartProperty.getSchemaMap().get(schema);
            String queryString = request.getQueryString();
            String decode = URLDecoder.decode(queryString, "UTF-8");
            String link = schema1 + "?" + decode;
            response.sendRedirect(link);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @PostMapping(value = {"/upload", "/files"})
    public ResponseEntity uploadMultipleFiles(MultipartHttpServletRequest request) {
        log.info(requestToString(request));
        ResponseEntity result = null;
        MultiValueMap requestMap = new LinkedMultiValueMap();
        requestMap.add("requestId", "" + UUID.randomUUID());
        String json = request.getParameter("json");
        Iterator<String> itr = request.getFileNames();
        int size = json == null ? request.getFileMap().size() : request.getFileMap().size() + 1;
        requestMap.add("requestFilesTotalCount", "" + size);
        int numberFile = 0;
        if (json != null) {
            MultiValueMap multiValueMap = new LinkedMultiValueMap();
            multiValueMap.addAll(requestMap);
            addFileNameAndNumber("json", ++numberFile, multiValueMap);
            String schema = addParamsAndReturnSchema(request, multiValueMap);
            addHeaders(request, multiValueMap);
            try {
                result = resendFile(new JsonMultipartFile("json", json.getBytes()), multiValueMap, schema);
                //                resendFile("json", json.getBytes(), multiValueMap, schema);
            } catch (Exception e) {
                log.error("Download file - json error", e);
                return errorResponse(HttpStatus.FAILED_DEPENDENCY, "Файл json не загрузился. Ошибка: " + e.getMessage());
            }
        }
        while (itr.hasNext()) {
            MultipartFile mFile = request.getFile(itr.next());
            MultiValueMap multiValueMap = new LinkedMultiValueMap();
            multiValueMap.addAll(requestMap);
            addFileNameAndNumber(mFile.getName(), ++numberFile, multiValueMap);
            String schema = addParamsAndReturnSchema(request, multiValueMap);
            addHeaders(request, multiValueMap);
            try {
                result = resendFile(mFile, multiValueMap, schema);
            } catch (Exception e) {
                log.error("Download file - " + mFile.getName() + " error", e);
                return errorResponse(HttpStatus.FAILED_DEPENDENCY, "Файл " + mFile.getName()
                        + " не загрузился. Ошибка: " + e.getMessage());
            }
        }
        if (result == null) {
            result = new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
        return result;
    }

    private void addFileNameAndNumber(String fileName, int number, MultiValueMap multiValueMap) {
        multiValueMap.add("requestCurrentFileName", fileName);
        multiValueMap.add("requestCurrentFileCount", "" + number);
    }

    private void addHeaders(MultipartHttpServletRequest request, MultiValueMap multiValueMap) {
        StringJoiner requestHeaders = new StringJoiner(";");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String paramName = headerNames.nextElement();
            requestHeaders.add(paramName + "=" + request.getHeader(paramName));
        }
        multiValueMap.add("requestHeaders", requestHeaders.toString());
    }

    private String addParamsAndReturnSchema(MultipartHttpServletRequest request, MultiValueMap multiValueMap) {
        String schema = null;
        Enumeration<String> params = request.getParameterNames();
        StringJoiner requestParams = new StringJoiner(";");
        while (params.hasMoreElements()) {
            String paramName = params.nextElement();
            if(!"json".equalsIgnoreCase(paramName)) {
                requestParams.add(paramName + "=" + request.getParameter(paramName));
            }
            if (MultipartProperty.SCHEMA.equalsIgnoreCase(paramName)) {
                schema = request.getParameter(paramName);
            }
        }
        multiValueMap.add("requestParams", requestParams.toString());
        return schema;
    }

    private String requestToString(MultipartHttpServletRequest request) {
        Enumeration<String> params = request.getParameterNames();
        StringJoiner requestParams = new StringJoiner(";");
        while (params.hasMoreElements()) {
            String paramName = params.nextElement();
            requestParams.add(paramName + "=" + request.getParameter(paramName));
        }
        StringJoiner requestHeaders = new StringJoiner(";");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String paramName = headerNames.nextElement();
            requestHeaders.add(paramName + "=" + request.getHeader(paramName));
        }

        return "params {" + requestParams.toString() + "},\n" +
                " headers {" + requestHeaders.toString() + "}\n" +
                " request {" + ObjectUtils.toString(request, true) + "}\n";
    }

    @PostMapping("/test")
    public ResponseEntity<String> uploadMultipleFilesTest(MultipartHttpServletRequest request) {
        Iterator<String> itr = request.getFileNames();
        while (itr.hasNext()) {
            MultipartFile file = request.getFile(itr.next());
            System.out.println(file.getName());
            Enumeration<String> params = request.getParameterNames();
            while (params.hasMoreElements()) {
                String paramName = params.nextElement();
                System.out.println(paramName + " = " + request.getParameter(paramName));
            }
            Enumeration<String> headerNames = request.getHeaderNames();
            while (headerNames.hasMoreElements()) {
                String paramName = headerNames.nextElement();
                System.out.println(paramName + " = " + request.getHeader(paramName));
            }
        }
        return new ResponseEntity("{\"fff\":\"fff\"}", HttpStatus.OK);
    }

    @PostMapping("/server-url")
    public ResponseEntity setServerUrl(@RequestParam("url") String url, @RequestParam("schema") String schema) {
        Map<String, String> schemaMap = multipartProperty.getSchemaMap();
        schemaMap.put(schema, url);
        return new ResponseEntity(getJsonSchemaMap(), HttpStatus.OK);
    }

    private ResponseEntity<String> errorResponse(HttpStatus status, String message) {
        return ResponseEntity.status(status).body(message);
    }

    public ResponseEntity<String> resendFile(String name, byte[] bytes, MultiValueMap map, String schema) throws IOException {
        String url = multipartProperty.getSchemaMap().get(schema);
        ResponseEntity<String> response =
                errorResponse(HttpStatus.BAD_REQUEST, "Не проинициализирована схема " + schema);
        if (url != null && !url.isEmpty()) {
            MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
            bodyMap.add(name, bytes);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            headers.addAll(map);
            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(bodyMap, headers);

            RestTemplate restTemplate = new RestTemplate();
            response = restTemplate.exchange(url,
                    HttpMethod.POST, requestEntity, String.class);
            System.out.println("response status: " + response.getStatusCode());
            System.out.println("response body: " + response.getBody());
        }
        return response;
    }

    public ResponseEntity<String> resendFile(MultipartFile multipartFile, MultiValueMap map, String schema) throws IOException {
        String url = multipartProperty.getSchemaMap().get(schema);
        ResponseEntity<String> response =
                errorResponse(HttpStatus.BAD_REQUEST, "Не проинициализирована схема " + schema);
        if (url != null && !url.isEmpty()) {
            MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
            bodyMap.add(multipartFile.getName(), multipartFile.getResource());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            headers.addAll(map);
            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(bodyMap, headers);

            RestTemplate restTemplate = new RestTemplate();
            response = restTemplate.exchange(url,
                    HttpMethod.POST, requestEntity, String.class);
            System.out.println("response status: " + response.getStatusCode());
            System.out.println("response body: " + response.getBody());
        }
        return response;
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//        headers.addAll(map);
//        MultiValueMap<String, Object> body
//                = new LinkedMultiValueMap<>();
//        body.add(file.getName(),file.getBytes());
//        HttpEntity<MultiValueMap<String, Object>> requestEntity
//                = new HttpEntity<>(body, headers);
//        RestTemplate restTemplate = new RestTemplate();
//        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
//        converter.setSupportedMediaTypes(
//                Arrays.asList(new MediaType[]{MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM}));
//
//        restTemplate.setMessageConverters(Arrays.asList(converter, new FormHttpMessageConverter()));
//        return restTemplate.postForEntity(multipartProperty.getServerUrl(), requestEntity, Object.class);

    }

    //    public ResponseEntity resendFile(MultipartFile multipartFile, MultiValueMap map) throws IOException {
//        Resource resource = multipartFile.getResource();
//        HttpHeaders headers = new HttpHeaders();
//        headers.addAll(map);
//        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
//        return ResponseEntity.ok()
//                .contentType(MediaType.APPLICATION_OCTET_STREAM)
//                .headers(headers)
//                .body(resource);
//    }
    private static class JsonMultipartFile implements MultipartFile, Serializable {
        private final String name;
        private String originalFilename;
        @Nullable
        private String contentType;
        private final byte[] content;

        public JsonMultipartFile(String name, @Nullable byte[] content) {
            this(name, "", (String) null, (byte[]) content);
        }

        public JsonMultipartFile(String name, InputStream contentStream) throws IOException {
            this(name, "", (String) null, (byte[]) FileCopyUtils.copyToByteArray(contentStream));
        }

        public JsonMultipartFile(String name, @Nullable String originalFilename, @Nullable String contentType, @Nullable byte[] content) {
            Assert.hasLength(name, "Name must not be null");
            this.name = name;
            this.originalFilename = originalFilename != null ? originalFilename : "";
            this.contentType = contentType;
            this.content = content != null ? content : new byte[0];
        }

        public JsonMultipartFile(String name, @Nullable String originalFilename, @Nullable String contentType, InputStream contentStream) throws IOException {
            this(name, originalFilename, contentType, FileCopyUtils.copyToByteArray(contentStream));
        }

        public String getName() {
            return this.name;
        }

        public String getOriginalFilename() {
            return this.originalFilename;
        }

        @Nullable
        public String getContentType() {
            return this.contentType;
        }

        public boolean isEmpty() {
            return this.content.length == 0;
        }

        public long getSize() {
            return (long) this.content.length;
        }

        public byte[] getBytes() throws IOException {
            return this.content;
        }

        public InputStream getInputStream() throws IOException {
            return new ByteArrayInputStream(this.content);
        }

        public void transferTo(File dest) throws IOException, IllegalStateException {
            FileCopyUtils.copy(this.content, dest);
        }

    }
}
