import re, sys, inspect, os

appName = 'ea-file-server'
warPath = os.path.join(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))),'target','ea-file-server.war')
print('full path =', warPath) # script directory

weblogicUrl = 't3://dda-test.gksm.local:7001'
userName = 'weblogic'
password = 'Welcome1'

connect(userName, password, weblogicUrl)

appList = re.findall(appName, ls('/AppDeployments'))
if len(appList) >= 1:
    print 'undeploying application'
    undeploy(appName)

deploy(appName, targets='dda_1', path = warPath, retireTimeout = -1, upload = 'True')
exit()
# C:\Oracle\Middleware\Oracle_Home\oracle_common\common\bin\wlst.sh testDeployment.py