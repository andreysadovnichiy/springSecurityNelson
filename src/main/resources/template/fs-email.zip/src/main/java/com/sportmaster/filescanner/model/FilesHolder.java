package com.sportmaster.filescanner.model;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Optional;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.concurrent.TimeUnit.SECONDS;

@Slf4j
@Component
public class FilesHolder {
    private BlockingQueue<File> files = new LinkedBlockingDeque<>();

    public void add(File file) {
        if (file != null) {
            try {
                files.put(file);
                log.debug("File add to queue to delete: " + file.getName());
            } catch (InterruptedException e) {
                log.error(e.getMessage());
            }
        }
    }

    public Optional<File> get() {
        try {
            File file = files.poll(10L, SECONDS);
            return of(file);
        } catch (InterruptedException e) {
            log.error(e.getMessage());
        }
        return empty();
    }

    public int size() {
        return files.size();
    }
}
