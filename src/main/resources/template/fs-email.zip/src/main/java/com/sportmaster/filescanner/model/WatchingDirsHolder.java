package com.sportmaster.filescanner.model;

import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

public class WatchingDirsHolder {
    private Set<Path> dirs = new HashSet<>();

    public void addPath(Path path) {
        dirs.add(path);
    }

    public Set<Path> getDirs() {
        return dirs;
    }
}
