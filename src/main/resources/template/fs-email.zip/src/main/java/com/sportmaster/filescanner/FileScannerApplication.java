package com.sportmaster.filescanner;

import com.sportmaster.filescanner.config.ParamsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileScannerApplication implements CommandLineRunner {
    @Autowired
    ParamsConfig paramsConfig;

    public static void main(String[] args) {
        SpringApplication.run(FileScannerApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Current server config: ");
        System.out.println(paramsConfig.toString());
    }
}