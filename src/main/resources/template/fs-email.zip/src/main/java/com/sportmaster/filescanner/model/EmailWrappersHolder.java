package com.sportmaster.filescanner.model;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.concurrent.TimeUnit.SECONDS;

@Slf4j
@Component
public class EmailWrappersHolder {
    private BlockingQueue<EmailWrapper> emails = new LinkedBlockingDeque<>();

    public void add(EmailWrapper wrapper) {
        if (wrapper != null) {
            try {
                emails.put(wrapper);
                log.debug("Email notification added to queue on file: " + wrapper.getFilename());
            } catch (InterruptedException e) {
                log.error(e.getMessage());
            }
        }
    }

    public Optional<EmailWrapper> get() {
        try {
            EmailWrapper email = emails.poll(1L, SECONDS);
            if (email != null && !email.isAttemptsToSendExpired()) {
                return of(email);
            }
        } catch (InterruptedException e) {
            log.error(e.getMessage());
        }
        return empty();
    }
}
