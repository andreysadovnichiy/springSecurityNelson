package com.sportmaster.filescanner;

import com.sportmaster.filescanner.config.ParamsConfig;
import com.sportmaster.filescanner.service.FileService;
import com.sportmaster.filescanner.service.ScannerService;
import com.sportmaster.filescanner.service.SmptMailService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.ExecutorService;


@Component
@AllArgsConstructor
public class Core {
    private ScannerService scannerService;
    private ParamsConfig paramsConfig;
    private SmptMailService mailService;
    private FileService fileService;
    private ExecutorService executorService;

    @PostConstruct
    private void runner() {
        scannerService.registerDirsToWatch();
        executorService.execute(() -> scannerService.scanWorker());
        executorService.execute(() -> mailService.sendWorker());
        executorService.execute(() -> fileService.deleteWorker());
        executorService.shutdown();
    }
}