package com.sportmaster.filescanner.service;

import com.sportmaster.filescanner.model.FilesHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static java.lang.Thread.sleep;

@AllArgsConstructor
@Slf4j
@Service
public class FileService {
    private FilesHolder filesHolder;

    public void deleteWorker() {
        log.debug("DeleteWorker started");
        while (true) {
            try {
                sleep(5000);
            } catch (InterruptedException e) {
                log.error(e.getMessage());
            }
            try {
                for (int i = 0; i < filesHolder.size(); i++) {
                    filesHolder.get().ifPresent(
                            file -> {
                                if (!file.delete()) {
                                    log.error("Could not delete file: " + file.getName());
                                    filesHolder.add(file);
                                } else {
                                    log.debug("Deleted file: " + file.getName());
                                }
                            });
                }
            } catch (Throwable e) {
                log.error(e.getMessage());
            }
        }
    }
}
