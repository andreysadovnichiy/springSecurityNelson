package com.sportmaster.filescanner.service;

import com.sportmaster.filescanner.config.ParamsConfig;
import com.sportmaster.filescanner.model.EmailWrapper;
import com.sportmaster.filescanner.model.WatchingDirsHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

import static com.sportmaster.filescanner.utils.OsResolver.resolveSlash;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;


@Slf4j
@AllArgsConstructor
@Service
public class ScannerService {
    private WatchService watchService;
    private WatchingDirsHolder watchingDirsHolder;
    private ParamsConfig propConfig;
    private SmptMailService mailService;

    public void registerDirsToWatch() {
        checkIfRootDirIsExists();
        findDirsToWatch();
        watchingDirsHolder.getDirs().forEach(s -> {
            try {
                s.register(watchService, ENTRY_CREATE);
            } catch (IOException e) {
                log.error("Couldn`t register dir to listening!");
                log.error(e.getMessage());
            }
        });
    }

    private void checkIfRootDirIsExists() {
        String scanDir = propConfig.getScanDir();
        File file = null;
        try {
            file = new File(scanDir);
        } catch (NullPointerException ignored) {
        }
        if (file == null || !file.isDirectory()) {
            log.error("Root directory - " + scanDir);
            log.error("Root directory does not exist or access denied!");
            System.exit(-1);
        }
    }

    private void findDirsToWatch() {
        FileVisitor<Path> simpleFileVisitor = new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                watchingDirsHolder.addPath(dir);
                log.debug("Listening directory: " + dir.toFile().getPath());
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path visitedFile, BasicFileAttributes fileAttributes) {
                return FileVisitResult.CONTINUE;
            }
        };
        Path rootPath = FileSystems.getDefault().getPath(propConfig.getScanDir());
        try {
            Files.walkFileTree(rootPath, simpleFileVisitor);
        } catch (IOException e) {
            log.error("Could not register dir to listening! Error: " + e.getMessage());
        }
    }

    public void scanWorker() {
        log.debug("ScanWorker started");
        WatchKey key;
        Path path;
        File file;
        while (true) {
            try {
                key = watchService.take();
                if (!propConfig.isScanDirEnabled()) {
                    key.reset();
                    continue;
                }
                for (WatchEvent<?> event : key.pollEvents()) {
                    path = (Path) event.context();
                    String curPath = key.watchable().toString() + resolveSlash() + path.toString();
                    file = new File(curPath);
                    if (file.isDirectory()) {
                        Paths.get(curPath).register(watchService, ENTRY_CREATE);
                        log.debug("Add directory to listening: " + curPath);
                    } else if (file.isFile()) {
                        mailService.updateMailQueue(
                                new EmailWrapper(file.getName(), file.getPath(), propConfig.getAttempsToSend())
                        );
                    }
                }
                key.reset();
            } catch (ClosedWatchServiceException ignored) {
            } catch (Throwable e) {
                log.error(e.getMessage());
            }
        }
    }
}