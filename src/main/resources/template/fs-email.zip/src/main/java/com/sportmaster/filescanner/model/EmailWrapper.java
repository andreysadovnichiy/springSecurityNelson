package com.sportmaster.filescanner.model;

import java.io.File;

public class EmailWrapper {
    private String filename;
    private String path;
    private int attempts;

    public EmailWrapper(String filename, String path, int attempts) {
        this.filename = filename;
        this.path = path;
        this.attempts = attempts;
    }

    public boolean isAttemptsToSendExpired() {
        return attempts < 1;
    }

    public void incAttempt() {
        attempts--;
    }

    public String getFilename() {
        return filename;
    }

    public String getPath() {
        return path;
    }

    public File getFile() {
        return new File(path);
    }
}