package com.sportmaster.filescanner.config;

import com.sportmaster.filescanner.exception.FileStorageException;
import com.sportmaster.filescanner.model.WatchingDirsHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.nio.file.WatchService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static java.nio.file.FileSystems.getDefault;

@Configuration
@Slf4j
public class Config {

    @Bean
    public WatchService watchService() {
        WatchService watchService;
        try {
            watchService = getDefault().newWatchService();
        } catch (IOException e) {
            log.error("Could not register WatchService: " + e.getMessage());
            throw new FileStorageException("Could not register WatchService");
        }
        return watchService;
    }

    @Bean
    public WatchingDirsHolder getWatchingDirsHolder() {
        return new WatchingDirsHolder();
    }

    @Bean
    public ExecutorService getExecutorService() {
        return Executors.newFixedThreadPool(3);
    }
}