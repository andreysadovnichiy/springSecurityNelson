package com.sportmaster.filescanner.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties
@Data

@PropertySource(value = {"classpath:application.yaml"})
public class ParamsConfig {
    private String scanDir;
    private boolean scanDirEnabled;
    private String mailTo;
    private String mailFrom;
    private String mailSubject;
    private String mailBody;
    private String mailBodyError;
    private String mailBodySizeToBig;
    private int attachedFileMaxSize;
    private int attempsToSend;
    private String mailHost;
    private int mailPort;
    private String mailUsername;
    private String mailPassword;
    private boolean customConfig;

    @Override
    public String toString() {
        return "{" + '\n' +
                "\t ! scan-dir-enabled = " + scanDirEnabled + '\n' +
                "\t ! custom-config enabled " + customConfig + '\n' +
                "\n\tscan-dir = " + scanDir + '\n' +
                "\tmailTo = " + mailTo + '\n' +
                "\tmailFrom = " + mailFrom + '\n' +
                "\tmailSubject = " + mailSubject + '\n' +
                "\tmailBody = " + mailBody + '\n' +
                "\tmailBodyError = " + mailBodyError + '\n' +
                "\tmailBodySizeToBig = " + mailBodySizeToBig + '\n' +
                "\tattachedFileMaxSize = " + attachedFileMaxSize + " bytes" + '\n' +
                "\tattempsToSend = " + attempsToSend + '\n' +
                "\tmailHost = " + mailHost + '\n' +
                "\tmailPort = " + mailPort + '\n' +
                "\tmailUsername = " + mailUsername + '\n' +
//                "mailPassword='" + mailPassword + '\'' +
                '}';
    }
}