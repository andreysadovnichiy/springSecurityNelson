package com.sportmaster.filescanner.service;

import com.sportmaster.filescanner.config.ParamsConfig;
import com.sportmaster.filescanner.model.EmailWrapper;
import com.sportmaster.filescanner.model.EmailWrappersHolder;
import com.sportmaster.filescanner.model.FilesHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Date;
import java.util.Optional;

import static java.lang.Thread.sleep;
import static java.util.Optional.empty;
import static java.util.Optional.of;

@AllArgsConstructor
@Slf4j
@Service
public class SmptMailService {
    private ParamsConfig config;
    private EmailWrappersHolder emailWrappersHolder;
    private FilesHolder filesHolder;
    private ParamsConfig params;

    public void sendWorker() {
        log.debug("EmailSenderWorker started");
        while (true) {
            try {
                sleep(5000);
            } catch (InterruptedException e) {
                log.error(e.getMessage());
            }
            for (int i = 20; i > 1; i--) {
                emailWrappersHolder.get().ifPresent(
                        wrapper ->
                                createMultiPartEmail(wrapper).ifPresent(
                                        email -> {
                                            try {
                                                String result = email.send();
                                                log.debug("Send: " + wrapper.getPath() + " - Result: " + result);
                                                filesHolder.add(wrapper.getFile());
                                            } catch (EmailException e) {
                                                updateMailQueue(wrapper);
                                                log.error("Notification email will resend later on file: " + wrapper.getFilename() + "Error message: " + e.getMessage());
                                            }
                                        }));
            }
        }
    }

    private Optional<MultiPartEmail> createMultiPartEmail(EmailWrapper wrapper) {
        wrapper.incAttempt();
        if (wrapper.isAttemptsToSendExpired()) {
            return empty();
        }
        File file = wrapper.getFile();
        MultiPartEmail email = new MultiPartEmail();
        email.setHostName(config.getMailHost());
        email.setSmtpPort(config.getMailPort());
        email.setAuthenticator(new DefaultAuthenticator(config.getMailUsername(), config.getMailPassword()));
        email.setSSLOnConnect(false);
        email.setSubject(config.getMailSubject());
        email.setSentDate(new Date());
        email.setCharset("utf-8");
        try {
            email.addTo(config.getMailTo());
            email.setFrom(config.getMailFrom());
            email.setMsg(config.getMailBody() + " " + file.getPath());
            if (file.length() <= config.getAttachedFileMaxSize()) {
                EmailAttachment ea = new EmailAttachment();
                ea.setDescription(file.getName());
                ea.setName(file.getName());
                ea.setPath(file.getPath());
                email.attach(ea);
            } else if (file.length() > config.getAttachedFileMaxSize()) {
                email.setMsg(config.getMailBodySizeToBig() + " " + file.getName());
            }
            return of(email);
        } catch (EmailException e) {
            log.error("Create email notification error on file: " + file.getName() + " with message: " + e.getMessage());
        }
        return empty();
    }

    public void updateMailQueue(EmailWrapper wrapper) {
        emailWrappersHolder.add(wrapper);
    }
}