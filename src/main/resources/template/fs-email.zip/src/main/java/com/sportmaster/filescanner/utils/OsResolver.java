package com.sportmaster.filescanner.utils;

public class OsResolver {
    private static String OS = System.getProperty("os.name").toLowerCase();

    public static boolean isWindows() {
        return OS.contains("win");
    }

    public static boolean isLinux() {
        return OS.contains("nux");
    }

    public static String resolveSlash() {
        return isWindows() ? "\\" : "/";
    }
}
