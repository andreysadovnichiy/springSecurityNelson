$(document).ready(function() {
	$('.accordion-title').click(function() {
		$(this).toggleClass('open');
		return false
	});
	$('.dropdown').click(function() {
		$(this).toggleClass('active');
		$(".wrap-dropdown").toggleClass('active');
		return false
	});
	$(document).mouseup(function (e){ 
		var div = $(".wrap-dropdown"); 
		if (!div.is(e.target) 
		    && div.has(e.target).length === 0) { 
			$(".wrap-dropdown").removeClass('active');
		}
	});
	$('.menu-btn').click(function() {
		$(this).toggleClass('close');
		$(".main-nav").toggleClass('open');
		$(".wrapper").toggleClass('open');
		return false
	});

	$('.tabs a').click(function() {
		var tabHref = $(this).attr('href');
		$('.tabs a').removeClass('current');
		$('.tab-content').removeClass('tab-content-show');

		$(this).addClass('current');
		$(tabHref).addClass('tab-content-show');
		return false
	});
});
